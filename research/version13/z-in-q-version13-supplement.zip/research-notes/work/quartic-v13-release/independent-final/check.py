"""Independent finite checks. Imports no producer or prior checker."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from math import gcd, lcm, comb
import json, hashlib, copy, sys
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[3]
REPO=ROOT/'work/quartic-version6-release/repository'
COM=ROOT/'work/quartic-under400-20261107/10-combination'
OUT=Path(__file__).parent
results={}
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def objsha(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def pin(p,h): assert sha(p)==h,(str(p),sha(p),h)
def terms(ts):
    d=defaultdict(F)
    for t in ts: d[(t.get('sPower',0),tuple(sorted(t['monomial'])))]+=F(t['coefficient'])
    return {k:v for k,v in d.items() if v}
def normalized(ts):
    d=terms(ts); c=d[min(d)]; return {k:v/c for k,v in d.items()}
def roweq(a,b): return a['name']==b['name'] and normalized(a['terms'])==normalized(b['terms'])
def byid(x): return {a['id']:a for a in x}
def byname(x): return {a['name']:a for a in x}
contract_path=REPO/'docs/manuscript-revisions/version13/quartic-application.json'
contract=read(contract_path)
pin(contract_path,'9369be2e7c73f62aede900c7de0782b978b115c0275e2bd2fff958f84e2786ba')
for b in [contract['manuscript'],*contract['evidence'].values()]: pin(REPO/b['path'],b['sha256'])
man=REPO/contract['manuscript']['path']
mb=man.read_bytes(); ml=mb.splitlines(keepends=True)
for s in contract['manuscript_spans']:
    assert hashlib.sha256(b''.join(ml[s['start_line']-1:s['end_line']])).hexdigest()==s['sha256']
edits=read(REPO/'docs/manuscript-revisions/version13/new-edits.json')
assert contract['reviewed_edits']=={e['id']:objsha(e) for e in edits if e['kind']=='mathematical'}
old=(REPO/'manuscripts/quartic_v12.tex').read_text(encoding='utf-8')
for e in edits:
    # new-edits intentionally stores the addition's original CRLF inside JSON.
    a=e['old'].replace('\r\n','\n'); b=e['new'].replace('\r\n','\n')
    assert old.count(a)==1,(e['id'],old.count(a))
    old=old.replace(a,b)
assert old==man.read_text(encoding='utf-8')
addition=(ROOT/'work/quartic-v13-prep/addition.tex').read_text(encoding='utf-8')
assert old.count(addition.rstrip())==1
results['assembly']={'contract':sha(contract_path),'manuscript':sha(man),'exact_edits':[e['id'] for e in edits]}
imap=read(ROOT/'work/quartic-v13-prep/integration-map.json')
spans=[]
for section in imap['sections']:
    for s in section.get('source_passages',[]):
        p=ROOT/s['path']; lines=p.read_bytes().splitlines(keepends=True)
        if p.name=='quartic_v12.tex': pin(p,imap['baseline_manuscript']['sha256'])
        assert hashlib.sha256(b''.join(lines[s['start_line']-1:s['end_line']])).hexdigest()==s['sha256_raw_utf8_span']
        spans.append([section['id'],s['start_line'],s['end_line']])
    for r in section.get('reviews',[]): pin(ROOT/r['path'],r['sha256'])
results['source_spans']=spans
apps=read(ROOT/'work/quartic-v13-prep/new-application-rows.json')
results['application_components']=[]
for c in apps['components']:
    for k in ['source','target','independent_review']: pin(ROOT/c[k]['path'],c[k]['sha256'])
    a=read(ROOT/c['source']['path']); b=read(ROOT/c['target']['path'])
    for kind,key in [('coordinates','changed_coordinates'),('residuals','changed_residuals')]:
        aa=byid(a[kind]); bb=byid(b[kind])
        actual={i for i in aa.keys()|bb.keys() if aa.get(i)!=bb.get(i)}
        assert actual=={r['id'] for r in c[key]},(c['id'],kind)
        for r in c[key]:
            assert r['old']==aa.get(r['id']) and r['new']==bb.get(r['id'])
    for x in c['coordinate_incidence']:
        for side,ir in [('old',a),('new',b)]:
            found=[r['id'] for r in ir['residuals'] if any(x['coordinate'] in t['monomial'] for t in r['terms'])]
            assert found==x[side+'_residuals'],(c['id'],x['coordinate'],side)
    results['application_components'].append(c['id'])
# Re-derive component deltas and apply them to the actual accumulated predecessor.
transport=[]
for name in ['combined486','combined461','combined439','combined435','combined433','combined432','combined431','combined423','combined417','combined401','combined399','combined396','combined395','combined394']:
    cp=COM/(name+'-certificate.json'); cert=read(cp)
    pin(COM/cert['source'],cert['sourceSha256'])
    current=read(COM/cert['source'])
    coords=byid(current['coordinates']); rows=byname(current['residuals'])
    stepchecks=[]
    for st in cert['steps']:
        for k in ['source','target','review']: pin(COM/st[k],st[k+'Sha256'])
        before=read(COM/st['source']); after=read(COM/st['target'])
        ac,bc=byid(before['coordinates']),byid(after['coordinates'])
        ar,br=byname(before['residuals']),byname(after['residuals'])
        rem=ac.keys()-bc.keys(); add=bc.keys()-ac.keys(); rename={i for i in ac.keys()&bc.keys() if ac[i]!=bc[i]}
        assert rem==set(st['removedCoordinates'])
        assert rename==set(st['renamedCoordinates'])
        cmap={i:i for i in ac.keys()|bc.keys()}; cmap.update({int(k):v for k,v in st['addedCoordinates'].items()})
        assert add=={int(k) for k in st['addedCoordinates']}
        for i in rem|rename:
            assert coords[i]==ac[i],(name,st['step'],'coord',i)
        for i in rem: del coords[i]
        for i in rename|add:
            z=copy.deepcopy(bc[i]); z['id']=cmap[i]; coords[cmap[i]]=z
        deleted=ar.keys()-br.keys(); added=br.keys()-ar.keys()
        changed={n for n in ar.keys()&br.keys() if not roweq(ar[n],br[n])}
        assert deleted==set(st['deletedRows']) and added==set(st['addedRows']) and changed==set(st['changedRows']),(name,st['step'],'delta')
        for n in deleted|changed: assert roweq(rows[n],ar[n]),(name,st['step'],'old-row',n)
        for n in deleted: del rows[n]
        for n in changed|added:
            z=copy.deepcopy(br[n]); z['id']=rows[n]['id'] if n in changed else st['addedRows'][n]
            for t in z['terms']: t['monomial']=[cmap[i] for i in t['monomial']]
            rows[n]=z
        stepchecks.append({'name':st['step'],'removed':len(rem),'changed_rows':len(changed),'added_rows':len(added)})
    target=read(COM/(name+'-ir.json'))
    assert coords==byid(target['coordinates']),(name,'final-coordinates')
    tr=byname(target['residuals'])
    assert rows.keys()==tr.keys() and all(roweq(rows[n],tr[n]) and rows[n]['id']==tr[n]['id'] for n in rows),(name,'final-rows')
    transport.append({'candidate':name,'steps':stepchecks})
results['derived_transports']=transport
# Full independent primitive sum-of-squares expansion and compact table comparison.
stats={}
for n in [394,411]:
    base=REPO/'quartics/quartic-394-411'
    ir=read(base/f'candidate{n}-ir.json'); ids=[x['id'] for x in ir['coordinates']]
    assert len(ids)==n and len(set(ids))==n
    assert [(c['id'],c['name']) for c in ir['coordinates'] if c.get('kind')=='input']==[(0,'input')]
    support=set(); poly=defaultdict(int)
    for r in ir['residuals']:
        ts=terms(r['terms']); assert max(len(k[1]) for k in ts)<=2
        den=lcm(*(v.denominator for v in ts.values())); ints={k:int(v*den) for k,v in ts.items()}; g=gcd(*ints.values())
        ints={k:v//g for k,v in ints.items()}
        for p,m in ints: support.update(m)
        for (p,m),v in ints.items():
            for (q,t),w in ints.items(): poly[(p+q,tuple(sorted(m+t)))]+=v*w
    poly={k:v for k,v in poly.items() if v}; assert support==set(ids)
    assert poly==terms(read(base/f'polynomial{n}.json')['terms'])
    label='symbolic' if n==394 else 'ordinary'
    tab=read(base/f'quartic-{n}-{label}-coefficients.json')
    cmap={i:j+1 for j,i in enumerate(sorted(ids))}
    for c in tab['coordinates']: assert c['id']==cmap[c['sourceId']]
    compact={(p,tuple(cmap[i] for i in m)):v for (p,m),v in poly.items()}
    assert compact==terms(tab['terms'])
    textrows={}
    for line in (base/f'quartic-{n}-{label}-coefficients.txt').read_text(encoding='utf-8').splitlines():
        if not line.strip() or line.startswith('#'): continue
        coefficient,power,indices=[part.strip() for part in line.split('|')]
        key=(int(power),tuple(int(i) for i in indices.split(',') if i))
        assert key not in textrows
        textrows[key]=int(coefficient)
    assert textrows==compact
    assert len(poly)==len({m for p,m in poly})
    assert gcd(*poly.values())==1 and max(len(m) for p,m in poly)==4
    stats[n]={'variables':n,'residuals':len(ir['residuals']),'monomials':len(poly),'degree':4,'content':1}
    if n==394:
        assert [(m,v) for (p,m),v in poly.items() if p==2]==[((57,57,549,549),16)]
        assert max(abs(v) for (p,m),v in poly.items() if p==1)==96
        assert max(abs(v).bit_length() for (p,m),v in poly.items() if p==0)==1520
    else:
        assert all(p==0 for p,m in poly)
        assert max(abs(v) for v in poly.values()).bit_length()==3247
        stats[n]['maximum_bits']=3247
results['numeric']=stats
# Derive the exact ordinary lift without evaluating the huge fixed integer.
base=REPO/'quartics/quartic-394-411'
symbolic=read(base/'candidate394-ir.json'); ordinary=read(base/'candidate411-ir.json')
sc=byid(symbolic['coordinates']); oc=byid(ordinary['coordinates'])
assert all(oc[i]==v for i,v in sc.items())
assert set(oc)-set(sc)==set(range(702,719))
sr=byname(symbolic['residuals']); ot=byname(ordinary['residuals'])
assert len(ot)-len(sr)==17
for name,row in sr.items():
    expected=defaultdict(F)
    for (p,m),v in terms(row['terms']).items():
        if p:
            assert name=='anchor.translatedEquation' and p==1 and m==(57,549) and v==-4
            expected[(0,(57,718))]+=v
        else: expected[(0,m)]+=v
    assert terms(ot[name]['terms'])==dict(expected)
added=[terms(ot[n]['terms']) for n in ot.keys()-sr.keys()]
expected=[{(0,()):F(-3**1024),(0,(702,)):F(1)}]
expected += [{(0,(i-1,i-1)):F(-1),(0,(i,)):F(1)} for i in range(703,718)]
expected += [{(0,(549,717)):F(-1),(0,(718,)):F(1)}]
for e in expected:
    assert e in added
    added.remove(e)
assert not added and 1024*2**15==2**25
results['ordinary_lift']={'unchanged_original_coordinates':394,'uniquely_forced_constant_coordinates':16,'product_gates':1,'changed_original_rows':['anchor.translatedEquation']}
# Exact rational-log certificate and residue tests from the displayed coefficients.
Q=[F(1),F(-1526,1073),F(513,1073)]
N=[F(1),F(-9776,5365),F(2941,3219),F(-1024,13949),F(-1920,237133),F(-1024,711399),F(-1408,5928325),F(0),F(2432,103152855)]
G=[F(1),F(-2,5)]
for j in range(2,10): G.append(F(4*j-5,4*j+1)*G[-1])
v=[F(0)]*12
for i,a in enumerate(Q):
    for j,b in enumerate(G): v[i+j]+=a*b
for i,a in enumerate(N): v[i]-=a
assert {i:a for i,a in enumerate(v) if a}=={10:F(2970726,254443709),11:F(-41697666,6361092725)}
for coeff,p in [(N,71),(Q,7)]:
    residue=[int(a.numerator*pow(a.denominator,-1,p)%p) for a in coeff]
    assert residue[-1]!=0
    assert all(sum(a*pow(x,i,p) for i,a in enumerate(residue))%p for x in range(p))
assert 12*12%71==2 and 3*3%7==2
assert F(5,24)*F('25165823.5')>2093966+7
# Integer-input local assertions, checked over complete relevant residue sets.
def rval(t):
    b=51*t*t+2504
    return b*(b-1)*(b-2401)*(32*b+343)*(2*b-1)
for t in range(1,32,2): assert rval(t)%32==4
for t in range(9): assert rval(t)%9 in (3,6)
for t in range(17): assert rval(t)%17==15
results['local_arithmetic']={'r_mod32':4,'r_mod9':[3,6],'r_mod17':15,'log_remainder':'exact','numerator_mod71':'no roots','denominator_mod7':'no roots'}
results['scope']='Independent finite evidence for new v13 application; not a substitute for mathematical proof or a new certification of inherited arithmetic.'
(OUT/'CHECKS.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':True,'transports':len(transport),'components':len(apps['components']),'numeric':stats,'contract':sha(contract_path)},indent=2))



