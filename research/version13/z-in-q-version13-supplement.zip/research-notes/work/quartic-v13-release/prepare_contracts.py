"""Prepare application records for independent decisions, never approvals."""
from pathlib import Path
import hashlib, json, shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'quartic-version6-release/repository'
OPT = HERE.parent / 'quartic-under400-20261107'
DEST = ROOT / 'docs/manuscript-revisions/version13'
EVIDENCE = DEST / 'evidence'
EVIDENCE.mkdir(exist_ok=True)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path): return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path.read_bytes())}
def put(path, value): path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
text_path = ROOT / 'manuscripts/quartic_v13.tex'
text = text_path.read_bytes().decode('utf-8')
lines = text.splitlines(keepends=True)
edits = json.loads((DEST / 'edits.json').read_bytes())

def fingerprints(cid):
    return {e['id']: sha(json.dumps(e, sort_keys=True, separators=(',', ':')).encode())
            for e in edits if e.get('contract_id') == cid}

def span(role, first, last):
    a = text.index(first)
    b = text.index(last, a)
    start, end = text.count('\n', 0, a) + 1, text.count('\n', 0, b)
    return {'role': role, 'start_line': start, 'end_line': end,
            'sha256': sha(''.join(lines[start-1:end]).encode())}

for name in ['kato', 'quartic']:
    old = json.loads((ROOT / f'docs/manuscript-revisions/version12/{name}-application.json').read_bytes())
    old['manuscript'] = pin(text_path)
    old['reviewed_edits'] = fingerprints(old['id'])
    if name == 'kato':
        old['manuscript_spans'] = [
            span('construction', r'\paragraph{1. One original lattice', r'\paragraph{5. One coefficient'),
            span('application', r'\paragraph{The published prime-two', r'\paragraph{8. Paying'),
            span('consumer', r'\paragraph{7. Every hypothesis', r'\paragraph{The published prime-two')]
    else:
        old['manuscript_spans'] = [
            span('construction', r'\section{A quartic in 498 variables}', r'\section{A quartic presentation with 394 variables}'),
            span('application', r'\subsection{Mixed logarithmic precision}', r'\section{A quartic presentation with 394 variables}'),
            span('consumer', r'\subsection{Conventions and retained arithmetic inputs}', r'\subsection{Rational logarithms and the two order-ten tests}')]
    old['dependency_impact'] += (' Version 13 preserves these historical mathematical edits and their source section. '
        'Its new abstract supersedes the old counts; the 498-variable construction remains an intermediate proof baseline. '
        'This record requests a fresh binding and dependency comparison, not approval of the separate new 394-variable argument.')
    put(DEST / (name + '-carryforward-application.json'), old)

copies = {
    'composition394-review.md': '03-depth/integrated394/REVIEW.md',
    'composition395-review.md': '03-depth/integrated395/REVIEW.md',
    'exposition-review.md': '01-elimination/v13-exposition/REVIEW.md',
    'artifact-review.md': '02-squares/release-review/REVIEW.md',
    'anchor-review.md': '01-elimination/review398/REVIEW.md',
    'H-domain-review.md': '01-elimination/review-H-domain/REVIEW.md',
    'preparation-review.md': '05-anchor/review-preparation-zero.md',
    'normalization-review.md': '05-anchor/review-normalized-pole.md',
    'one-correction-review.md': '03-depth/review-one-correction.md',
    'deterministic-correction-review.md': '03-depth/review-deterministic-correction.md',
    'biquadratic-review.md': '03-depth/review-biquadratic411.md',
}
for name, src in copies.items(): shutil.copyfile(OPT / src, EVIDENCE / name)
shutil.copyfile(OPT / '10-combination/release394/ARTIFACTS.json', EVIDENCE / 'release-artifacts.json')
evidence = {p.stem: pin(p) for p in EVIDENCE.iterdir() if p.is_file()}
artifacts = json.loads((EVIDENCE / 'release-artifacts.json').read_bytes())
packet = ROOT / 'quartics/quartic-394-411'
packet.mkdir(parents=True, exist_ok=True)
for name, expected in artifacts['files'].items():
    source = OPT / '10-combination/release394' / name
    raw = source.read_bytes()
    assert sha(raw) == expected, name
    target = packet / name
    if target.exists():
        assert target.read_bytes() == raw, 'Existing artifact differs: ' + name
    else:
        target.write_bytes(raw)
    evidence['artifact-' + name] = pin(target)
evidence['addition'] = pin(DEST / 'addition.tex')
evidence['baseline'] = pin(ROOT / 'manuscripts/quartic_v12.tex')
sources = json.loads((ROOT / 'docs/manuscript-revisions/version12/quartic-application.json').read_bytes())['sources']
sources.append({
    'id': 'internal-v12',
    'url': 'https://github.com/elliotglazer/diophantine-z-q/blob/f0d105b6a8cff1db021c0bebdd0ca1612be2a433/manuscripts/quartic_v12.tex',
    'version': 'Frozen Version 12 internal manuscript; inherited results retain their source and review qualifications, not an independently published external theorem.',
    'locator': 'Retained generator, one-place, height, scalar coefficient, real-progression and preparation-zero lemmas; exact applications in the Version 13 inventory.',
    'sha256': sha((ROOT / 'manuscripts/quartic_v12.tex').read_bytes())})

def obligation(required, constructed, justification, extra=()):
    return {'status': 'checked', 'required': required, 'constructed': constructed,
            'justification': justification, 'sources': ['silverman', 'voight', 'internal-v12'],
            'evidence': ['addition', 'baseline', 'composition394-review', 'composition395-review', *extra]}

contract = {
    'id': 'QUARTIC-394-COMPOSITION', 'manuscript': pin(text_path),
    'reviewed_edits': fingerprints('QUARTIC-394-COMPOSITION'),
    'authors': ['/root', '/root/astra_bl5_models', '/root/astra_quartic_opt01_elimination',
                '/root/astra_quartic_opt02_squares', '/root/astra_quartic_opt03_depth',
                '/root/astra_quartic_opt06_product', '/root/astra_quartic_opt10_combination'],
    'sources': sources, 'evidence': evidence,
    'manuscript_spans': [
        span('construction', r'\section{A quartic presentation with 394 variables}', r'\begin{thebibliography}{99}'),
        span('application', r'\subsection{Conventions and retained arithmetic inputs}', r'\begin{thebibliography}{99}'),
        span('consumer', r'\begin{abstract}', r'\end{abstract}')],
    'obligations': {
        'source_hypotheses': obligation('All inherited arithmetic hypotheses and every newly used lemma must apply to the constructed points and local conditions.', 'The same K, curve, generator, odd root labels, p>76176 places, height constant and pole inputs; revised H may be outside 2E(K).', 'The addition replaces every affected H-index identity, proves exceptional-H exclusion before ratios and checks the scalar and comparison applications separately. Published inputs retain the existing version/convention qualifications.', ['H-domain-review']),
        'constructed_objects': obligation('An integer polynomial with exactly the stated rational projection; fixed coefficients distinct from variables.', '394-coordinate quadratic system, primitive sum of squares, and 411-coordinate ordinary coefficient companion.', 'The full composition review distinguishes source enlargements from exact witness maps. The numerical review checks reindexing, all coefficients and both companion transformations.', ['artifact-review', 'release-artifacts']),
        'index_domain_coverage': obligation('Soundness for every allowed rational solution and simultaneous witnesses for every integer input, including identities and half-indices.', 'Ui and Vi may equal O; H=mR0+T with h=m/2 at odd primes; scalar R retains nonzero even index.', 'The addition uses analytic unit identities at O, integral group identities killing two-torsion and an anchor-first exclusion of exceptional H. Completeness retains old-subgroup witnesses.', ['H-domain-review', 'anchor-review']),
        'transition_maps': obligation('Exact maps, degrees and nonzero divisors in each reduction, plus an adequate arithmetic proof where no old-witness bijection is claimed.', 'Shared reciprocals, norm charts, scaled biquadratic charts, normalized poles, rescaled anchor and extra ordinary multiplication gate.', 'All maps and exceptional branches appear in the addition; consumer checks bind their outputs to the same root, logarithm and scalar values. General H and preparation-zero completeness are separately justified.', ['biquadratic-review', 'normalization-review', 'anchor-review', 'artifact-review']),
        'limiting_object_identity': obligation('The published coefficient table must be the sum of squares of the exact reviewed arithmetic system.', 'Frozen394 and its compact input-first table; uniquely constrained 16 constant-chain coordinates and one product gate in the ordinary companion.', 'Complete coefficient reconstruction and coordinate-map checks establish the finite identity; no new analytic limit is introduced. Existing analytic inputs are not certified by this finite computation.', ['artifact-review', 'release-artifacts']),
        'coefficient_conventions': obligation('Correct basis, normalized valuations, fixed-parameter interpretation, total counts and coefficient bounds.', 'C=3^(2^25); 394 total variables and 6338 terms, 411 total and 6388 terms; content one, degree four.', 'The symbolic maximum is 16C^2 at W^2*tau^2, with no collisions. The ordinary maximum is 3247 bits and its text is 214957 bytes. Exact physical x-coordinate scalings are included in the source comparisons.', ['artifact-review', 'anchor-review']),
        'local_conditions': obligation('Preserve formal-depth transfer and local squareclasses and ensure the finite/real conditions hold simultaneously.', 'Order-ten input tests, order-forty remaining tests, depth24 scalar transfer, beta=51(2X+1)^2+2504 and c=r+4896.', 'Correction-unit assertions are restricted to consumed contact primes. Preparation includes the whole support of cr and primes2,3,17; real-open-set and CRT choices use one compatible order and preserve the final b<17 bound.', ['one-correction-review', 'deterministic-correction-review', 'preparation-review']),
        'exceptional_cases': obligation('No forbidden division, circular nonvanishing argument, free identity branch or wrong real-component assumption.', 'Zero comparison numerators; general H and H-P; scalar R near O or T0; anchor g1=0; private pole zero branches.', 'Exceptional H are excluded using pre-ratio root heights and the restored anchor. Modular certificates replace global positivity of rational-log numerators. The even-index coefficient lemma precedes inverse restoration. Both scalar local branches and pole zero branches are retained.', ['H-domain-review', 'anchor-review', 'normalization-review']),
        'downstream_consumption': obligation('Reduced precision and altered domains must still yield integer input soundness, all-integer completeness and the reported final polynomial.', 'Unchanged exponent19 heights and anchor, scalar24 margin, revised local ratios, oddness plus squarefree51 input bridge.', 'The final addition supplies the needed inequalities and simultaneous construction. Exact final consumers and coefficient artifacts have separate reviews; the abstract uses only their verified counts and bounds.', ['exposition-review', 'artifact-review'])
    },
    'dependency_impact': 'Covers only the new Version 13 abstract, introduction and full reduction section. Prior mathematical sections remain byte-identical; their historical inputs and review qualifications are retained. The original huge polynomial is unchanged. General-H and identity-inclusive extensions have new soundness arguments rather than assumed witness bijections. The strict standalone protocol is not represented as a newly completed whole-historical-proof audit. Author records await a fresh non-author independent decision on this exact contract and manuscript.'
}
put(DEST / 'quartic-application.json', contract)
print(json.dumps({p.name: pin(p) for p in DEST.glob('*application.json')}, indent=2))
