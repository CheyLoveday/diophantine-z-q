"""Prepare the Version13 supplement only after the root declares final state.

No action occurs on import. Running requires --final-state. The final registry
must bind Version13 and pass its own independent-review checks before an archive
is made. Publication files are written only after a fresh restore passes all
three requested validators. This script does not create approval records.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import io
import json
import stat
import subprocess
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
DEFAULT_REPO = HERE.parent / 'quartic-version6-release/repository'
WORKSPACE = HERE.parents[1]
DATE = (2026, 11, 7, 0, 0, 0)
BASE_HASH = 'ef8772aa4929071ab4f8e40a249b9e91f53ba5dbeaff6d7845f517ee7869f9e7'
V13 = 'docs/manuscript-revisions/version13'
PACKET = 'quartics/quartic-394-411'

# This is an explicit selection, not a recursive archive of the repository or
# workstation. Further files come only from the named manifests and JSON pins.
CORE_FILES = [
    'manuscripts/quartic_v13.tex', 'manuscripts/quartic_v13.pdf',
    'manuscripts/quartic_v12.tex', 'manuscripts/quartic_v11.tex',
    'manuscripts/README.md', 'README.md', 'CITATION.bib', 'AGENTS.md',
    '.gitattributes', '.gitignore',
    '.github/workflows/research-checks.yml',
    '.github/workflows/manuscript-integration.yml',
    '.github/workflows/handoff-release.yml',
    'scripts/build_paper.py', 'scripts/check_quartic394.py',
    'scripts/check_quartic394_portable.py', 'scripts/quartic394_path_bootstrap.py',
    'scripts/check_quartic498.py', 'scripts/check_audit_history.py',
    'scripts/check_application_reviews.py', 'scripts/render_quartic_review.py',
    'docs/building.md', 'docs/research-guide.md', 'docs/release-policy.md',
    'docs/archiving.md', 'docs/audit-history/PROTOCOL.md',
    'docs/audit-history/current.json', 'docs/theorem-application-audit/sources.json',
    'research/version13/README.md', 'quartics/README.md',
    'quartics/quartic-394-symbolic-coefficients.json',
    'quartics/quartic-394-symbolic-coefficients.txt',
    'quartics/quartic-411-fully-expanded.txt',
    V13 + '/addition.tex', V13 + '/APPLICATIONS.json',
    V13 + '/integration-map.json', V13 + '/new-application-rows.json',
    V13 + '/validate-applications.py', V13 + '/validation-schema.json',
    V13 + '/inventory-install-manifest.json', V13 + '/VALIDATION.json',
    V13 + '/README.md', V13 + '/GUIDE.md', V13 + '/build-report.json', V13 + '/pdf-qa.json',
    V13 + '/edits.json', V13 + '/new-edits.json', V13 + '/v12-review-record.json',
    V13 + '/kato-carryforward-application.json',
    V13 + '/kato-carryforward-acceptance.json',
    V13 + '/quartic-carryforward-application.json',
    V13 + '/quartic-carryforward-acceptance.json',
    V13 + '/quartic-application.json',
    V13 + '/portability/test_portability.py', V13 + '/portability/REVIEW.md',
    V13 + '/portability/acceptance.json', V13 + '/portability/README.md',
]
RESEARCH_FILES = [
    'work/quartic-under400-20261107/06-product/scalar-post399/REPORT.md',
    'work/quartic-under400-20261107/06-product/scalar-post399/CENSUS.json',
    'work/quartic-under400-20261107/06-product/scalar-post399/ELIMINATION-AUDIT.json',
    'work/quartic-under400-20261107/06-product/scalar-post399/audit_eliminations.py',
    'work/quartic-under400-20261107/06-product/scalar-post399/MANIFEST.json',
    'work/quartic-v13-prep/inventory/build.py',
    'work/quartic-v13-prep/inventory/specs.py',
    'work/quartic-v13-prep/inventory/validate.py',
    'work/quartic-v13-prep/inventory/PATH-MAP.json',
    'work/quartic-v13-prep/inventory/REPORT.md',
    'work/quartic-v13-prep/inventory/INSTALL-MANIFEST.json',
    'work/quartic-v13-prep/inventory/author-originals/addition.tex',
    'work/quartic-v13-prep/inventory/author-originals/integration-map.json',
    'work/quartic-v13-prep/inventory/author-originals/new-application-rows.json',
    'work/quartic-v13-release/package_v13.py',
    'work/quartic-v13-release/prepare_manuscript.py',
    'work/quartic-v13-release/prepare_contracts.py',
    'work/quartic-v13-release/pin_final_evidence.py',
    'work/quartic-v13-release/install_packet.py',
    'work/quartic-v13-release/install_inventory.py',
    'work/quartic-v13-release/pdf_qa.py',
    'work/quartic-v13-release/independent-final/check.py',
]
CHECKS = [
    ['scripts/check_audit_history.py', '--self-test'],
    [V13 + '/validate-applications.py', '--repo', '.', '--self-test'],
    [V13 + '/portability/test_portability.py'],
    ['scripts/check_quartic394_portable.py'],
]
FORBIDDEN_PARTS = {'.git', '.aws', '.ssh', '__pycache__', 'node_modules',
                   'conversations', 'transcripts', 'credentials'}
FORBIDDEN_NAMES = {'.env', 'id_rsa', 'id_ed25519', 'credentials.json',
                   'conversation.json', 'transcript.json', 'auth.json'}
ARCHIVAL_RELOCATIONS = {
    'manuscripts/quartic_v7.tex': 'manuscripts/archive/quartic_v7.tex',
    'manuscripts/quartic_v8.tex': 'manuscripts/archive/quartic_v8.tex',
    'quartic_12504.tex': 'manuscripts/archive/quartic_12504.tex',
    'quartic_9625.tex': 'manuscripts/archive/quartic_9625.tex',
    'quartic_4973.tex': 'manuscripts/archive/quartic_4973.tex',
    'quartic_1272.tex': 'manuscripts/archive/quartic_1272.tex',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True) + '\n').encode()


def safe_name(name):
    p = PurePosixPath(name)
    if (not isinstance(name, str) or not name or p.is_absolute() or
            '\\' in name or ':' in name or '\x00' in name or
            any(part in ('', '.', '..') for part in name.split('/'))):
        raise ValueError('Unsafe archive path: ' + repr(name))
    reserved = {'con', 'prn', 'aux', 'nul'} | {'com'+str(i) for i in range(1,10)} | {'lpt'+str(i) for i in range(1,10)}
    if any(x.endswith((' ', '.')) or x.split('.')[0].lower() in reserved for x in p.parts):
        raise ValueError('Ambiguous Windows archive path: ' + repr(name))
    return p


def admissible(name, manuscript_pdf=False):
    p = safe_name(name)
    if any(x.lower() in FORBIDDEN_PARTS for x in p.parts) or p.name.lower() in FORBIDDEN_NAMES:
        raise ValueError('Excluded private/runtime file: ' + name)
    if p.suffix.lower() in ('.pem', '.key', '.p12', '.pfx'):
        raise ValueError('Excluded credential file: ' + name)
    if p.suffix.lower() == '.pdf' and not manuscript_pdf:
        raise ValueError('Source PDF redistribution is not permitted: ' + name)
    if p.suffix.lower() == '.zip':
        raise ValueError('Only the separately pinned historical base ZIP is allowed')


def pinned_path(root, name):
    safe_name(name)
    p = (root / name).resolve()
    if not p.is_relative_to(root.resolve()) or not p.is_file() or p.is_symlink():
        raise ValueError('Missing, escaping, or symbolic-link input: ' + name)
    return p


def historical_base_index(repo):
    """Index the exact files supplied by the preserved, hash-verified base.

    This applies the same overlay order as restore.py. It does not reinterpret
    old external-PDF metadata as a request to redistribute source books.
    """
    raw = (repo / 'research/version12/z-in-q-version12-supplement.zip').read_bytes()
    if sha(raw) != BASE_HASH:
        raise ValueError('Changed historical base')
    index = {}
    def layer(data, where):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            m = json.loads(z.read('MANIFEST.json'))
            for name, digest in sorted(m['files'].items()):
                safe_name(name)
                if name.endswith('-base.zip'):
                    child = z.read(name)
                    if sha(child) != digest:
                        raise ValueError('Changed nested historical base')
                    layer(child, where + '/' + name)
            has_current = any(n.startswith('current/') for n in m['files'])
            for name, digest in sorted(m['files'].items()):
                if name.endswith('-base.zip') or name in ('restore.py', 'README.txt'):
                    continue
                if has_current and not name.startswith('current/'):
                    continue
                logical = name[8:] if name.startswith('current/') else name
                index[logical] = {'sha256': digest, 'layer': where, 'member': name}
    layer(raw, 'version12-base.zip')
    return index


def collect(repo):
    current = {}
    origins = {}
    todo = []
    archival_mappings = set()
    base_index = historical_base_index(repo)
    author_relocations = json.loads((WORKSPACE / 'work/quartic-v13-prep/inventory/PATH-MAP.json').read_bytes())

    def add(name, why, expected=None):
        admissible(name, manuscript_pdf=(name == 'manuscripts/quartic_v13.pdf'))
        try:
            p = pinned_path(repo, name)
        except ValueError as error:
            raise ValueError(str(error) + '; requested by ' + why) from error
        raw = p.read_bytes()
        if expected is not None and sha(raw) != expected:
            raise ValueError('Stale selected source pin: ' + name + '; requested by ' + why + '; expected ' + expected + '; actual ' + sha(raw))
        if name in current and current[name] != raw:
            raise ValueError('Input changed while selecting: ' + name)
        new = name not in current
        current[name] = raw
        origins.setdefault(name, []).append(why)
        if new and p.suffix == '.json' and not name.startswith(PACKET + '/'):
            inherited = base_index.get(name)
            if name not in CORE_FILES and inherited and inherited['sha256'] == sha(raw):
                # A verified immutable historical record is already supplied by
                # the base. Preserve it rather than walk its old external source
                # catalog as if it were a new executable dependency declaration.
                archival_mappings.add((name, name, inherited['layer'] + ':' + inherited['member'], sha(raw)))
            else:
                todo.append(name)

    for name in CORE_FILES:
        add(name, 'explicit core selection')
    packet_manifest = json.loads((repo / PACKET / 'PACKAGE-MANIFEST.json').read_bytes())
    add(PACKET + '/PACKAGE-MANIFEST.json', 'selected packet manifest')
    for name, item in packet_manifest.items():
        add(PACKET + '/' + name, 'packet manifest', item['sha256'])
        if len(current[PACKET + '/' + name]) != item['bytes']:
            raise ValueError('Packet byte count mismatch: ' + name)

    # The install manifest enumerates its layer, while the operative application
    # pins determine which bytes remain binding. README or packaging notes may
    # have received separately reviewed integration edits after installation.
    installation = json.loads((repo / V13 / 'inventory-install-manifest.json').read_bytes())
    for name in installation['files']:
        add(name, 'inventory installation layer enumeration')

    def visit(value, source):
        if isinstance(value, list):
            for v in value:
                visit(v, source)
        elif isinstance(value, dict):
            name = value.get('path')
            if isinstance(name, str) and isinstance(value.get('sha256'), str):
                if name in ARCHIVAL_RELOCATIONS:
                    relocated = ARCHIVAL_RELOCATIONS[name]
                    add(relocated, 'validated historical relocation from ' + source, value['sha256'])
                    archival_mappings.add((source, name, relocated, value['sha256']))
                elif name.startswith('work/'):
                    relocated = author_relocations.get(name, PACKET + '/sources/' + name)
                    add(relocated, 'validated source-packet relocation from ' + source, value['sha256'])
                    archival_mappings.add((source, name, relocated, value['sha256']))
                elif '://' in name or ':' in name or name.startswith('/'):
                    raise ValueError('Unexpected nonportable operative pin in ' + source)
                elif PurePosixPath(name).suffix.lower() == '.zip':
                    if name != 'research/version12/z-in-q-version12-supplement.zip' or value['sha256'] != BASE_HASH:
                        raise ValueError('Historical ZIP requires an explicit validated layer mapping: ' + name)
                    archival_mappings.add((source, name, 'version12-base.zip', BASE_HASH))
                else:
                    add(name, 'structured pin from ' + source, value['sha256'])
            for v in value.values():
                visit(v, source)

    seen = set()
    while todo:
        name = todo.pop()
        if name in seen:
            continue
        seen.add(name)
        visit(json.loads(current[name]), name)

    registry = json.loads(current['docs/audit-history/current.json'])
    if registry['manuscript']['path'] != 'manuscripts/quartic_v13.tex':
        raise ValueError('The current registry has not reached Version13 final state')
    if registry['manuscript']['sha256'] != sha(current['manuscripts/quartic_v13.tex']):
        raise ValueError('The current registry does not bind the selected manuscript')
    inventory = json.loads(current[V13 + '/APPLICATIONS.json'])
    if len(inventory['applications']) != 39:
        raise ValueError('Expected the reviewed 39-application Version13 inventory')

    research = {}
    for name in RESEARCH_FILES:
        admissible(name)
        research[name] = pinned_path(WORKSPACE, name).read_bytes()
    # All additional selected under400 proofs/checkers already occur explicitly
    # in SOURCE-MANIFEST.json. Index them rather than rescan arbitrary work dirs.
    sm = json.loads(current[PACKET + '/SOURCE-MANIFEST.json'])
    for name, item in sm.items():
        key = PACKET + '/sources/' + name
        if key not in current or sha(current[key]) != item['sha256'] or len(current[key]) != item['bytes']:
            raise ValueError('Source layer disagrees with package manifest: ' + name)
    history = {'sourceManifest': PACKET + '/SOURCE-MANIFEST.json',
               'sourceManifestSha256': sha(current[PACKET + '/SOURCE-MANIFEST.json']),
               'sourceEntryCount': len(sm),
               'selectedSourceTree': PACKET + '/sources/',
               'additionalExplicitFiles': sorted(research),
               'scope': 'Selected source history only; not conversations or a complete workstation archive.'}
    return current, research, origins, sorted(archival_mappings), history


RESTORE = r'''"""Verify and restore the layered Version13 supplement safely."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, stat, sys, zipfile

ROOT = Path(__file__).resolve().parent
def digest(raw): return hashlib.sha256(raw).hexdigest()
def safe(name):
    p=PurePosixPath(name)
    if (not name or p.is_absolute() or ':' in name or '\\' in name or '\x00' in name
            or any(x in ('','.','..') for x in name.split('/'))):
        raise ValueError('Unsafe member path: '+repr(name))
    reserved={'con','prn','aux','nul'}|{'com'+str(i) for i in range(1,10)}|{'lpt'+str(i) for i in range(1,10)}
    if any(x.endswith((' ','.')) or x.split('.')[0].lower() in reserved for x in p.parts):
        raise ValueError('Ambiguous Windows member path')
    return p
def checked_zip(raw):
    z=zipfile.ZipFile(io.BytesIO(raw));seen=set()
    for i in z.infolist():
        safe(i.filename)
        if i.filename.casefold() in seen: raise ValueError('Duplicate/case-colliding ZIP member')
        seen.add(i.filename.casefold())
        if i.is_dir() or stat.S_ISLNK(i.external_attr >> 16): raise ValueError('Nonregular ZIP member')
    m=json.loads(z.read('MANIFEST.json'))
    if set(z.namelist()) != set(m['files'])|{'MANIFEST.json'}:
        raise ValueError('Unmanifested or missing member')
    for name,h in m['files'].items():
        safe(name)
        if digest(z.read(name))!=h: raise ValueError('Layer hash mismatch: '+name)
    return z,m
def main():
    if len(sys.argv)!=2: raise SystemExit('Usage: python -B restore.py NEW_DIRECTORY')
    dest=Path(sys.argv[1]).resolve()
    if dest.exists(): raise SystemExit('Choose a new output directory; existing paths are never merged')
    m=json.loads((ROOT/'MANIFEST.json').read_bytes())
    for name,h in m['files'].items():
        safe(name);p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT.resolve()) or p.is_symlink() or not p.is_file():
            raise ValueError('Unsafe or missing extracted input: '+name)
        if digest(p.read_bytes())!=h: raise ValueError('Supplement hash mismatch: '+name)
    names={}
    def save(name,raw):
        safe(name);old=names.get(name.casefold())
        if old is not None and old!=name: raise ValueError('Cross-layer case collision')
        names[name.casefold()]=name;p=(dest/name).resolve()
        if not p.is_relative_to(dest): raise ValueError('Restore target escaped')
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    def layer(raw,depth=0):
        if depth>16: raise ValueError('Historical layer depth limit exceeded')
        z,lm=checked_zip(raw)
        with z:
            for name in sorted(lm['files']):
                if name.endswith('-base.zip'): layer(z.read(name),depth+1)
            has_current=any(n.startswith('current/') for n in lm['files'])
            for name in sorted(lm['files']):
                if name.endswith('-base.zip') or name in ('restore.py','README.txt'): continue
                if has_current and not name.startswith('current/'): continue
                save(name[8:] if name.startswith('current/') else name,z.read(name))
    layer((ROOT/'version12-base.zip').read_bytes())
    for name in sorted(m['files']):
        if name.startswith('current/'): save(name[8:],(ROOT/name).read_bytes())
    print('Restored Version13 with verified historical bases; research notes stay beside this script.')
if __name__=='__main__': main()
'''


def write_zip(path, files):
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(files.items()):
            safe_name(name)
            info = zipfile.ZipInfo(name, date_time=DATE)
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)


def extract_checked(path, dest):
    with zipfile.ZipFile(path) as z:
        manifest = json.loads(z.read('MANIFEST.json'))
        if set(z.namelist()) != set(manifest['files']) | {'MANIFEST.json'}:
            raise ValueError('Archive membership mismatch')
        seen = set()
        for item in z.infolist():
            safe_name(item.filename)
            if item.filename.casefold() in seen or stat.S_ISLNK(item.external_attr >> 16):
                raise ValueError('Duplicate or symbolic-link archive member')
            seen.add(item.filename.casefold())
            raw = z.read(item.filename)
            if item.filename != 'MANIFEST.json' and sha(raw) != manifest['files'][item.filename]:
                raise ValueError('Archive hash mismatch')
            p = (dest / item.filename).resolve()
            if not p.is_relative_to(dest.resolve()):
                raise ValueError('Extraction escaped staging directory')
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(raw)


def run_check(args, cwd, log):
    with log.open('wb') as out:
        result = subprocess.run([sys.executable, '-X', 'utf8', '-B', *args], cwd=cwd,
                                stdout=out, stderr=subprocess.STDOUT, check=False)
    if result.returncode:
        raise RuntimeError('Validation failed; inspect ' + str(log))
    return {'command': args, 'returncode': 0, 'logSha256': sha(log.read_bytes())}


def write_new_or_equal(path, raw):
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError('Refusing to replace a different existing publication file: ' + str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--final-state', action='store_true',
                        help='Use only after the root explicitly declares the complete reviewed state final.')
    args = parser.parse_args()
    if not args.final_state:
        parser.error('No archive was built. Wait for the root final-state instruction, then pass --final-state.')
    repo = args.repo.resolve()
    current, research, origins, archival, history = collect(repo)
    print('Selected %d current files and %d explicit research files; %d validated archival mappings.' % (len(current), len(research), len(archival)), flush=True)
    # Existing approvals are checked by their own validator. Packaging does not
    # manufacture acceptance or edit the current registry.
    preflight = HERE / 'package-preflight-audit.log'
    run_check(CHECKS[0], repo, preflight)
    print('Final registry preflight passed.', flush=True)
    base = (repo / 'research/version12/z-in-q-version12-supplement.zip').read_bytes()
    receipt12 = json.loads((repo / 'research/version12/SUPPLEMENT.json').read_bytes())
    if sha(base) != BASE_HASH or receipt12['sha256'] != BASE_HASH or len(base) != receipt12['bytes']:
        raise ValueError('The Version12 supplement is not the unchanged pinned base')
    with zipfile.ZipFile(io.BytesIO(base)) as z:
        base_manifest = z.read('MANIFEST.json')
    files = {'current/' + n: b for n, b in current.items()}
    files.update({'research-notes/' + n: b for n, b in research.items()})
    files['research-notes/SELECTION.json'] = encode(history)
    files['version12-base.zip'] = base
    files['restore.py'] = RESTORE.encode()
    files['README.txt'] = (
        'Version13 research supplement: the selected394/411 quartics.\n'
        'Run python -B restore.py NEW_DIRECTORY, then the commands in research/version13/README.md.\n'
        'The unchanged Version12 supplement retains its own nested manifests.\n'
        'Selected source history is research evidence, not approval of every abandoned candidate.\n'
        'No conversations, credentials or external source PDFs are newly distributed.\n'
        'Finite validation and application-record integrity do not establish inherited arithmetic claims.\n'
    ).encode()
    files['layer-manifests/current-files.json'] = encode({n: {'sha256': sha(b), 'bytes': len(b), 'selection': origins[n]} for n, b in sorted(current.items())})
    files['layer-manifests/research-files.json'] = encode({n: {'sha256': sha(b), 'bytes': len(b)} for n, b in sorted(research.items())})
    files['layer-manifests/version12-manifest.json'] = base_manifest
    files['layer-manifests/archival-path-notes.json'] = encode(archival)
    manifest = {'schema': 'version13-supplement-1', 'date': '2026-11-07',
                'scope': 'Selected394/411 construction, exact Version13 manuscript and records, portable39-application inventory, selected research source history, and unchanged Version12 base.',
                'layers': {'base': {'path': 'version12-base.zip', 'sha256': BASE_HASH},
                           'current': 'layer-manifests/current-files.json',
                           'research': 'layer-manifests/research-files.json'},
                'files': {n: sha(b) for n, b in sorted(files.items())}}
    files['MANIFEST.json'] = encode(manifest)
    # This new, resolved temporary directory is inside the intended workspace.
    # Cleanup is restricted to this directory; restore.py never deletes anything.
    with tempfile.TemporaryDirectory(prefix='v13-package-', dir=HERE) as tmp:
        staging = Path(tmp).resolve()
        if not staging.is_relative_to(HERE.resolve()):
            raise ValueError('Unexpected staging directory')
        archive = staging / 'z-in-q-version13-supplement.zip'
        write_zip(archive, files)
        print('Private deterministic archive written; checking a fresh restore.', flush=True)
        extracted = staging / 'extracted'
        extract_checked(archive, extracted)
        restored = staging / 'restored'
        run_check([str(extracted / 'restore.py'), str(restored)], staging, HERE / 'package-restore.log')
        checks = []
        for i, command in enumerate(CHECKS, 1):
            checks.append(run_check(command, restored, HERE / ('package-restored-check-%d.log' % i)))
            print('Fresh-restore check %d/%d passed: %s' % (i, len(CHECKS), command[0]), flush=True)
        # Refuse a race with any source edit during the long finite replay.
        for name, raw in current.items():
            if pinned_path(repo, name).read_bytes() != raw:
                raise ValueError('Source changed during final validation: ' + name)
        for name, raw in research.items():
            if pinned_path(WORKSPACE, name).read_bytes() != raw:
                raise ValueError('Research source changed during final validation: ' + name)
        raw = archive.read_bytes()
        output = repo / 'research/version13/z-in-q-version13-supplement.zip'
        receipt = {'path': output.relative_to(repo).as_posix(), 'sha256': sha(raw),
                   'bytes': len(raw), 'files': len(manifest['files']), 'scope': manifest['scope'],
                   'restoredChecks': [{'command': c['command'], 'returncode': c['returncode']} for c in checks],
                   'baseSha256': BASE_HASH}
        write_new_or_equal(output, raw)
        write_new_or_equal(output.parent / 'SUPPLEMENT.json', encode(receipt))
        (HERE / 'package-replay.json').write_bytes(encode({'status': 'passed', 'receipt': receipt, 'checks': checks,
                                                        'freshRestore': True, 'sourceRaceCheck': 'passed'}))
        print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
