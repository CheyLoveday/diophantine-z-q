"""Bind installed data to the author contract before final review."""
from pathlib import Path
import hashlib, json, shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'quartic-version6-release/repository'
DEST = ROOT / 'docs/manuscript-revisions/version13'
def pin(path):
    return {'path': path.relative_to(ROOT).as_posix(),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')

shutil.copyfile(ROOT / 'build/paper/quartic_v13.pdf', ROOT / 'manuscripts/quartic_v13.pdf')
shutil.copyfile(ROOT / 'build/paper/build-report.json', DEST / 'build-report.json')
qa = json.loads((HERE / 'pdf-qa.json').read_bytes())
qa['status'] = 'Title and every new-section page rendered and visually inspected; no clipping, overlap or broken references observed.'
qa['manuscript'] = pin(ROOT / 'manuscripts/quartic_v13.tex')
qa['pdf'] = pin(ROOT / 'manuscripts/quartic_v13.pdf')
write(DEST / 'pdf-qa.json', qa)
record_path = DEST / 'quartic-application.json'
record = json.loads(record_path.read_bytes())
for name, path in {
    'application-inventory': DEST / 'APPLICATIONS.json',
    'inventory-validator': DEST / 'validate-applications.py',
    'inventory-install-manifest': DEST / 'inventory-install-manifest.json',
    'source-package-manifest': ROOT / 'quartics/quartic-394-411/PACKAGE-MANIFEST.json',
    'source-package-replay': ROOT / 'quartics/quartic-394-411/verify_lineage.py',
    'finite-replay-wrapper': ROOT / 'scripts/check_quartic394.py',
    'pdf-builder': ROOT / 'scripts/build_paper.py',
    'build-receipt': DEST / 'build-report.json',
    'pdf-inspection': DEST / 'pdf-qa.json',
}.items():
    record['evidence'][name] = pin(path)
for name in ['source_hypotheses', 'index_domain_coverage', 'transition_maps', 'local_conditions',
             'exceptional_cases', 'downstream_consumption']:
    record['obligations'][name]['evidence'].append('application-inventory')
record['obligations']['limiting_object_identity']['evidence'].extend(
    ['source-package-manifest', 'source-package-replay', 'finite-replay-wrapper'])
write(record_path, record)
print(json.dumps(pin(record_path)))
