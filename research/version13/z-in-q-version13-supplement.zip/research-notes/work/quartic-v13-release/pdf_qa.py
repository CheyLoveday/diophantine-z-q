"""Render the title and all new-section pages for visual inspection."""
from pathlib import Path
import contextlib, json, logging, os, subprocess
from pypdf import PdfReader
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'quartic-version6-release/repository'
BIN = Path('C:/Users/glaze/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
PDF = ROOT / 'build/paper/quartic_v13.pdf'
OUT = HERE / 'render'
OUT.mkdir(exist_ok=True)
logging.disable(logging.CRITICAL)
with open(os.devnull, 'w') as sink, contextlib.redirect_stderr(sink):
    pages = [page.extract_text() for page in PdfReader(PDF).pages]
start = max(i + 1 for i, page in enumerate(pages)
            if 'Aquarticpresentationwith394variables' in ''.join(page.split()))
end = next(i + 1 for i in range(start - 1, len(pages)) if 'References' in pages[i])
selected = [1, *range(start, end + 1)]
for page in selected:
    subprocess.run([str(BIN / 'pdftoppm.exe'), '-f', str(page), '-l', str(page),
                    '-singlefile', '-r', '95', '-png', str(PDF), str(OUT / f'p{page:03}')],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for offset in range(0, len(selected), 9):
    group = selected[offset:offset + 9]
    sheet = Image.new('RGB', (1350, 630 * ((len(group) + 2) // 3)), '#ddd')
    draw = ImageDraw.Draw(sheet)
    for index, page in enumerate(group):
        im = Image.open(OUT / f'p{page:03}.png')
        im.thumbnail((445, 600))
        x, y = index % 3 * 450, index // 3 * 630
        sheet.paste(im, (x, y + 25))
        draw.text((x + 8, y + 5), f'Page {page}', fill='black')
    sheet.save(OUT / f'sheet{offset // 9 + 1}.png')
data = {'pages': len(pages), 'section_start': start, 'section_end': end, 'rendered': selected,
        'status': 'rendered; human/model visual inspection still required'}
(HERE / 'pdf-qa.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
print(json.dumps(data))
