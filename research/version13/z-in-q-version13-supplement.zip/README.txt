Version13 research supplement: the selected394/411 quartics.
Run python -B restore.py NEW_DIRECTORY, then the commands in research/version13/README.md.
The unchanged Version12 supplement retains its own nested manifests.
Selected source history is research evidence, not approval of every abandoned candidate.
No conversations, credentials or external source PDFs are newly distributed.
Finite validation and application-record integrity do not establish inherited arithmetic claims.
