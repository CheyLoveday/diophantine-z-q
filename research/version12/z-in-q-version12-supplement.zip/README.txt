Version 12 research supplement: 498/514-variable quartics.
Run python -B restore.py restored, then the commands in current/research/version12/README.md from the restored directory.
Research notes preserve candidate work; only the selected frozen construction is accepted for this edition.
No conversational transcript. Source PDFs are referenced, not redistributed.
