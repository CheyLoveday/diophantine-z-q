# Order-10 source replay and toric check

`source_check.py` rebuilds the mixed-depth source with exactly two changes to its mathematical data: the two low comparison orders change from 12 to 10, and the corresponding weight q12=q*e^22 is replaced by q10=q*e^18. The alternate logarithm itself remains ell12=zG2. The new six-coordinate weight circuit is agent07's construction.

All logarithm, test-value and grouped-polynomial coefficient residuals are checked equal to the prior mixed-depth source after changing only the order-group names from 12 to 10. This works because the partition into groups is still nine low-formality tests, two input-comparison tests and five order-forty tests. The test expressions and their elementary symmetric polynomials are unchanged. Their evaluation now uses the correct q10 weight.

The source gate checker and complete first-stage polynomial checker pass on the rebuilt source. The first compiled system has 522 coordinates, against 528 for the prior mixed-depth system. This confirms six total coordinate savings from the new circuit, two per detector, before the unchanged later eliminations. It is not itself the final combined 498-coordinate artifact.

## Independent check of agent07's six-coordinate circuit

Put q=q1, E=e, and use the already retained powers q5=q^5 and R=q10^2. The new equations are

    E*a=q,
    E*b=a^2,
    q*c=b^2,
    c*d=q5,
    c*q10=d^2,
    c*q40=R^2.

The unchanged detector domain proves E and q nonzero. Therefore these equations successively force

    a=q E^-1,
    b=q^2 E^-3,
    c=q^3 E^-6,
    d=q^2 E^6,
    q10=q E^18,
    q40=q E^78.

In particular c is nonzero before any division by it. Conversely these rational values solve the equations for every allowed E,q. The retained q5 power chain and the retained R=q10^2 equation supply exactly the objects consumed in the fourth and sixth equations. No extraneous component at c=0 exists, and no new zero guard is required. Every displayed residual is quadratic in existing or new coordinates.

I independently checked this circuit algebra and its insertion into the raw source. I did not author the circuit. The accompanying order-10 height argument in `ARITHMETIC.md` is my own work and still requires review by someone else. This document does not present that arithmetic argument as independently accepted.

The final artifact assembled by agent07 is `07-toric/further/candidate498.json`. The new six-node circuit replaces the prior seven-node mixed-toric circuit at each of three detectors, giving 498 rather than 501 coordinates. Its sourceId remapping and full final sum of squares should be checked by the final-composition reviewer; the source replay here establishes the logarithm/test interpretation and the six-variable net saving relative to the original mixed-depth source.
