"""Read-only independent checks for the anchor review; no producer imports."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json
H=Path(__file__).resolve().parent;W=H.parent;R=W.parent/'quartic-version6-release/repository'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(a,c):return tuple(x*c for x in a)
def mul(a,b):return a[0]*b[0]+2*a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def inverse(a):return scale((a[0],-a[1]),1/(a[0]*a[0]-2*a[1]*a[1]))
def quotient(a,b):return mul(a,inverse(b))
x=(Q(57,8),Q(-7,2));y=(Q(-165,8),Q(417,32));D=(Q(11),Q(-6))
assert mul(y,y)==add(mul(mul(x,x),x),scale(mul(D,x),-1))
slope=quotient(add(scale(mul(x,x),3),scale(D,-1)),scale(y,2))
xx=add(mul(slope,slope),scale(x,-2));yy=add(mul(slope,add(x,scale(xx,-1))),scale(y,-1))
z=scale(quotient(xx,yy),-1)
assert z==(Q(3396356159088,3287811625151),Q(-4135204317756,3287811625151))
def mod3(a):return a.numerator*pow(a.denominator,-1,3)%3
assert tuple(mod3(v/3) for v in z)==(2,1)
assert tuple(v%3 for v in mul((2,1),(2,1)))==(0,1)
f=inverse(xx)
assert tuple(mod3(v/9) for v in f)==(0,1)
candidate=W/'10-combination/candidate505-ir.json';poly=W/'10-combination/polynomial505.json'
assert sha(candidate)=='bd9aca7a4a31476e426660d1a33de33552f2a5019bec06104b45938d59f4b966'
c=read(candidate);rows={r['name']:r for r in c['residuals']}
def polynomial(ts):return {(t.get('sPower',0),tuple(t['monomial'])):Q(t['coefficient']) for t in ts}
anchor=polynomial(rows['anchor.translatedEquation']['terms'])
assert anchor=={(0,(55,55)):Q(1),(0,(56,56)):Q(6),(0,(57,57)):Q(-2),(0,(505,505)):Q(-3),(1,(57,)):Q(-4)}
assert [r['name'] for r in c['residuals'] if any(set(t['monomial'])&{55,56,57} for t in r['terms'])]==['anchor.translatedEquation']
assert 'anchor.physicalA.definition' not in rows
depth=read(W/'03-depth/beta12/final/candidate-ir.json')
assert depth['values']['Sscalar.f.1']['terms']==[{'monomial':[505],'sPower':0,'coefficient':'1/1'}]
assert c['fixedParameter']=={'name':'C','value':'3^(2^25)','coordinate':False}
p=polynomial(read(poly)['terms'])
assert [(m,a) for (s,m),a in p.items() if s==2]==[((57,57),Q(16))]
assert not any(s<2 and m==(57,57) for s,m in p)
assert max(abs(a) for (s,m),a in p.items() if s==1)<=48
assert max(abs(a.numerator).bit_length() for (s,m),a in p.items() if s==0)==1520
assert p[(0,(57,57,57,57))]==4
files=[W/'05-anchor/REPORT.md',W/'05-anchor/candidate522-smallcoeff-ir.json',candidate,poly,R/'manuscripts/quartic_v11.tex',W.parent/'astra-final-size-independent-review-001/silverman-2009.pdf']
print(json.dumps({'localDirection':list(map(str,z)),'normalizedResidue':[0,1],'anchorCoefficient':505,'maxCoefficient':'16*C^2 = 16*3^(2^26)','sha256':{str(p):sha(p) for p in files}},indent=2))
