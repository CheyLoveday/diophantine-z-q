"""Read-only independent review check of the final norm elimination."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
H=Path(__file__).resolve().parent.parent/'10-combination'
def read(n):return json.loads((H/n).read_text())
def sha(n):return hashlib.sha256((H/n).read_bytes()).hexdigest()
def p(ts):return {(t.get('sPower',0),tuple(t['monomial'])):F(t['coefficient']) for t in ts}
def add(a,b):
 c=a.copy()
 for m,x in b.items():c[m]=c.get(m,F(0))+x
 return {m:x for m,x in c.items() if x}
def scale(a,x):return {m:v*x for m,v in a.items() if v*x}
def mul(a,b):
 c={}
 for (s,m),x in a.items():
  for (t,n),y in b.items():
   k=(s+t,tuple(sorted(m+n)));c[k]=c.get(k,F(0))+x*y
 return {m:x for m,x in c.items() if x}
def v(i):return {(0,(i,)):F(1)}
def subst(a,x,z):
 c={}
 for (s,m),y in a.items():
  t={(s,tuple(i for i in m if i!=x)):y}
  for j in range(m.count(x)):t=mul(t,z)
  c=add(c,t)
 return c
assert sha('candidate499-ir.json')=='8be28d88a5c37567a965288d39e11d69267ae309e5a7e61526311983f3ee17fc'
assert sha('candidate498-ir.json')=='7682a1229149c75e27322e86dec424449b55321b06c48e468f90fa78bcebb61a'
before=read('candidate499-ir.json');after=read('candidate498-ir.json')
br={r['id']:p(r['terms']) for r in before['residuals']};ar={r['id']:p(r['terms']) for r in after['residuals']}
bc={c['id']:c for c in before['coordinates']};ac={c['id']:c for c in after['coordinates']}
assert [bc[i]['name'] for i in [140,141,311,312,535]]==['U0.f.0','U0.f.1','testSquare.40.0.0.quadratic','testSquare.40.0.1.quadratic','reduced_scalar.norm_fH']
a,b,t,u,q=map(v,[140,141,311,312,535]);a2=mul(a,a);b2=mul(b,b)
tvalue=add(a2,scale(b2,2));uvalue=mul(a,b);qvalue=add(a2,scale(b2,-2))
assert br[263]==add(tvalue,scale(t,-1))
assert br[264]==add(uvalue,scale(u,-1))
assert br[505]==add(q,scale(qvalue,-1))
assert {i for i,z in br.items() if any(535 in m for s,m in z)}=={505,506}
assert all(535 not in m or m==(535,535) for s,m in br[506])
assert br[506][(0,(535,535))]==-1
expected=add(add(br[506],mul(q,q)),add(scale(mul(t,t),-1),scale(mul(u,u),8)))
assert ar[506]==expected
f1=add(tvalue,t);f2=scale(add(uvalue,u),-8)
assert add(add(subst(br[506],535,qvalue),mul(f1,br[263])),mul(f2,br[264]))==ar[506]
assert subst(br[505],535,qvalue)=={}
assert {i:z for i,z in br.items() if i not in [505,506]}=={i:z for i,z in ar.items() if i!=506}
assert {i:c for i,c in bc.items() if i!=535}==ac
assert before['fixedParameter']==after['fixedParameter']
assert all(535 not in m for z in ar.values() for s,m in z)
assert len(ac)==498 and len(ar)==467
cert=read('certificate498.json')
assert len(cert['operations'])==1
op=cert['operations'][0];assert op['coordinate']==535 and op['pivot']==505 and p(op['replacement'])==qvalue
assert len(op['changes'])==1
change=op['changes'][0];assert change['row']==506 and p(change['result'])==expected
assert {x['row']:p(x['factor']) for x in change['multiples']}=={263:f1,264:f2}
print(json.dumps({'accepted':'norm-coordinate elimination only','sourceSha256':sha('candidate499-ir.json'),'targetSha256':sha('candidate498-ir.json'),'certificateSha256':sha('certificate498.json'),'removedCoordinate':535,'removedRow':505,'changedRow':506,'retainedIdentityRows':[263,264],'uniqueInverse':'q=a^2-2*b^2','otherRowsAndCoordinatesUnchanged':True},indent=2))
