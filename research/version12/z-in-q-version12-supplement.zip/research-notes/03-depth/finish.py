from experiment import ROOT,REPO,SRC,COMPILER
import importlib.util,json,hashlib,copy,subprocess,sys
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
V=load('V',REPO/'quartics/quartic-523-540/final523_540/verify_elimination.py')
old=json.loads((SRC/'expected/source532.json').read_text())
new=json.loads((ROOT/'beta12/compiled/compiled-ir.json').read_text())
oldcert=json.loads((REPO/'quartics/quartic-523-540/final523_540/symbolic523/modulo-certificate.json').read_text())
cn={c['name']:c['id'] for c in new['coordinates']};rn={r['name']:r['id'] for r in new['residuals']}
cm={c['id']:cn[c['name']] for c in old['coordinates'] if c['name'] in cn}
rm={r['id']:rn[r['name']] for r in old['residuals'] if r['name'] in rn}
def trterms(ts):
 return [{**t,'monomial':sorted(cm[v] for v in t['monomial'])} for t in ts]
rows={r['id']:V.readpoly(r['terms']) for r in new['residuals']};coords={c['id']:c for c in new['coordinates']}
cert={'baselineSha256':hashlib.sha256((ROOT/'beta12/compiled/compiled-ir.json').read_bytes()).hexdigest(),'operations':[]}
for op in oldcert['operations'][:5]:
 x=cm[op['coordinate']];pivot=rm[op['pivot']];q=V.readpoly(trterms(op['replacement']))
 assert V.subst(rows[pivot],x,q)=={}
 affected={r for r,p in rows.items() if x in V.variables(p)}
 changes=[]
 for ch in op['changes']:
  r=rm[ch['row']];expected=V.subst(rows[r],x,q);mults=[]
  for m in ch['multiples']:
   rr=rm[m['row']];f=trterms(m['factor']);expected=V.add(expected,V.mul(V.readpoly(f),rows[rr]));mults.append({'row':rr,'factor':f})
  assert expected==V.readpoly(trterms(ch['result'])) and V.degree(expected)<=2
  changes.append({'row':r,'result':V.terms(expected),'multiples':mults})
 assert {c['row'] for c in changes}==affected-{pivot}
 cert['operations'].append({'coordinate':x,'name':coords[x]['name'],'pivot':pivot,'replacement':V.terms(q),'changes':changes})
 for ch in changes:rows[ch['row']]=V.readpoly(ch['result'])
 del rows[pivot];del coords[x]
print('Five exact inherited eliminations:',len(coords))
for order,k in [(1,5),(40,3)]:
 for j in range(2):
  free=cn[f'detector2.E{order}.high.{j}.quadratic']
  shears=[{'coordinate':cn[f'detector{r}.E{order}.high.{j}.quadratic'],'factor':'1'} for r in [0,1]]
  cc=cn[f'symmetric.{order}.co{k}.{j}.quadratic']
  factors=[]
  for pp in rows.values():
   for (ss,mm),aa in pp.items():
    if ss==0 and len(mm)==2 and free in mm:
     other=list(mm);other.remove(free)
     bb=pp.get((0,tuple(sorted([cc]+other))))
     if bb:factors.append(-aa/bb)
  assert factors and len(set(factors))==1,(order,j,factors)
  shears.append({'coordinate':cc,'factor':str(factors[0])})
  for sh in shears:
   v=sh['coordinate'];q={(0,(v,)):V.Q(1),(0,(free,)):V.Q(sh['factor'])}
   rows={r:V.subst(p,v,q) for r,p in rows.items()}
  assert max(map(V.degree,rows.values()))<=2
  cert['operations'].append({'kind':'shear','free':free,'shears':shears})
  pivots=[r for r,p in rows.items() if p.get((0,(free,))) and all(free not in m or (s,m)==(0,(free,)) for s,m in p)]
  done=False
  for pivot in pivots:
   p=rows[pivot];a=p[(0,(free,))];q={k:-v/a for k,v in p.items() if k!=(0,(free,))}
   affected={r for r,p in rows.items() if free in V.variables(p)}
   changed={r:V.subst(rows[r],free,q) for r in affected-{pivot}}
   if all(V.degree(p)<=2 for p in changed.values()):
    cert['operations'].append({'coordinate':free,'name':coords[free]['name'],'pivot':pivot,'replacement':V.terms(q),'changes':[{'row':r,'result':V.terms(p),'multiples':[]} for r,p in changed.items()]})
    rows.update(changed);del rows[pivot];del coords[free];done=True;break
  assert done,(order,j,pivots)
print('After shared-coefficient shears:',len(coords))
out=ROOT/'beta12/final';out.mkdir(exist_ok=True)
result=copy.deepcopy(new);result['coordinates']=list(coords.values());result['residuals']=[{**r,'terms':V.terms(rows[r['id']])} for r in new['residuals'] if r['id'] in rows]
(out/'candidate-ir.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'modulo-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
subprocess.run([sys.executable,str(COMPILER),str(out/'candidate-ir.json'),str(out/'polynomial'),'--no-reduce'],check=True,stdout=(out/'compiler.log').open('w'))
print(json.loads((out/'polynomial/compiler-report.json').read_text())['final'])
