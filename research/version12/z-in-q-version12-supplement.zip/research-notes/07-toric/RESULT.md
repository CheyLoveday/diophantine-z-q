# Toric reduction from 523 to 520 coordinates

The current 523-coordinate residual system admits an exact replacement with 520 coordinates, 519 existential witnesses, and 489 quadratic residuals. Its primitive integer sum of squares has degree four and 35,154 monomials. This is an algebraic projection equivalence to the existing system and requires no new arithmetic assumption.

## Source verification

The source is `quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json`, SHA-256 `48a8b8f9263a97d3a1c59f3f0f3553eae628b7aba342d44003e8da840ae84928`. It has 523 coordinates and 492 residuals. The checker verifies that primitive normalization of every source residual agrees with the package's compiled IR.

For each detector write E for `eWeight` and q for `q1`. Direct inspection of `source-reproduction/builders/odd-product-asymmetric-source.cjs`, lines 220–229, gives E=(A delta)^5/F and q=E/delta^3. In particular q is not E/F when F denotes the contact polynomial. The seven old internal coordinates are E^-1, E^-3, E^-7, E^-14, E^-29, E^-55, and q12=q E^22; their output is q40=q E^78. The checker verifies all eight old defining residuals coefficient by coefficient, up to sign.

The retained `E1.power2` and `E1.power3` coordinates satisfy q2=q^2 and q3=q q2=q^3. Their defining residuals are also checked coefficient by coefficient. The old seven internal coordinates have no consumer outside the eight removed residuals. There are three detectors in current523.

## Replacement equations

Reuse six internal coordinate slots for a,b,c,d,u,v and retain the q40 output slot. Delete the q12 slot. Replace the eight old equations by these seven:

```
E a = 1
a b = E^2
b c = a
b d = c^2
d u = q b
d v = u^2
q3 q40 = v^2
```

Here q3 is the existing `E1.power3` coordinate, so it costs no additional coordinate. Every residual is quadratic, including the last one. The exact values forced by these equations are

```
a = E^-1
b = E^3
c = E^-4
d = E^-11
u = q E^14
v = q^2 E^39
q40 = q E^78.
```

The checker verifies every equation by addition of two-component Laurent exponent vectors for E and q.

## Projection equivalence over the rationals

The unchanged norm block has a retained inverse of w0 and equations

```
w0 n = (w0^2 - 2 w1^2)/2
(E delta) B = n^2.
```

Since w0 is nonzero and 2 is not a rational square, n is nonzero. The second equation then forces E and delta nonzero. The retained q-definition gives q delta^3=E, so q and q3=q^3 are nonzero. This argument does not use any changed internal coordinate and works in either residual system.

Given an old rational solution, retain every outside coordinate, including q40 and q3, and assign a,b,c,d,u,v the values displayed above. The old equations force q40=q E^78, so all seven new equations hold.

Conversely, in a new rational solution E a=1 forces a nonzero. Then a b=E^2 forces b nonzero and b=E^3. Successive equations give c=E^-4 and d=E^-11, hence d nonzero. They then give u=q E^14 and v=q^2 E^39. Since q3=q^3 is nonzero, the last equation gives q40=q E^78. Restore the old internal values E^-1,E^-3,E^-7,E^-14,E^-29,E^-55,q E^22. Every removed equation holds, and every outside residual is unchanged. These maps preserve the input and every outside coordinate.

Taking the sum of the squares of primitive integer residuals preserves the rational zero set. The expansion has degree exactly four. It has a coefficient equal to 1 or -1 independent of the fixed S parameter, so its content is one after S specialization as well. The unchanged 17-coordinate constant lift would give a 537-coordinate ordinary-coefficient version.

## Reproduction and artifacts

Run `check_candidate.py` with Python 3.10 or later. It writes `candidate520.json`, `polynomial520.json`, and `report.json` in this directory. These files are scratch artifacts; no repository source or publication file was edited.

`search.py` exhaustively rules out seven-step sequential quadratic Laurent circuits from the independent seeds 1,E,q. Its span pruning is valid because each new exponent can at most double the current E-exponent span. `search_existing_q.py` finds the successful seven-step circuit once the already-required q^2 through q^5 coordinates are supplied. The reduction is not a claim of global optimality in the full residual system.
