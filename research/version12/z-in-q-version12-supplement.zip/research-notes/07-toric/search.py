from itertools import combinations_with_replacement
from time import monotonic
START=monotonic(); visited=[0]*8
sol=None
def dfs(vals, ops, remain):
 global sol
 depth=7-remain; visited[depth]+=1
 lo=min(x[0] for x in vals); hi=max(x[0] for x in vals)
 if (hi-lo)*(2**remain)<78:return False
 if remain==0:return vals[-1]==(78,1)
 candidates={}
 for a,b in combinations_with_replacement(range(len(vals)),2):
  for c in range(len(vals)):
   x=vals[a][0]+vals[b][0]-vals[c][0]
   if not (x<lo or x>hi):continue
   if x>78:continue
   nlo=min(lo,x); nhi=max(hi,x)
   if (nhi-nlo)*(2**(remain-1))<78:continue
   if remain==1 and x!=78:continue
   y=vals[a][1]+vals[b][1]-vals[c][1]
   if remain==1 and y!=1:continue
   candidates.setdefault((x,y),(a,b,c))
 for val,op in candidates.items():
  if dfs(vals+[val],ops+[op],remain-1):
   if sol is None:sol=(vals+[val],ops+[op])
   return True
 return False
print(dfs([(0,0),(1,0),(0,1)],[],7),sol,visited,monotonic()-START)
