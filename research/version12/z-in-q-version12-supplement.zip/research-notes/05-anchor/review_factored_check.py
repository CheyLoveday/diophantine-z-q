"""Independent all-row substitution check for the factored pole proposal."""
from pathlib import Path
from fractions import Fraction as Q
from math import gcd,lcm
from functools import reduce
import json,hashlib
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'10-combination/candidate501-ir.json'
NEW=HERE.parent/'02-squares/factored/candidate498-ir.json'
POLY=NEW.parent/'polynomial498.json'
def add(p,q):
    out=p.copy()
    for m,c in q.items():out[m]=out.get(m,Q(0))+c
    return {m:c for m,c in out.items() if c}
def times(p,q):
    out={}
    for m,c in p.items():
        for n,d in q.items():
            mn=tuple(sorted(m+n));out[mn]=out.get(mn,Q(0))+c*d
    return {m:c for m,c in out.items() if c}
def atom(c,*m):return {tuple(sorted(m)):Q(c)} if c else {}
def read(ts):
    out={}
    for t in ts:
        key=tuple(sorted([-1]*t.get('sPower',0)+t['monomial']))
        out[key]=out.get(key,Q(0))+Q(t['coefficient'])
    return {m:c for m,c in out.items() if c}
def sub(p,ss):
    out={}
    for m,c in p.items():
        term=atom(c)
        for v in m:term=times(term,ss.get(v,atom(1,v)))
        out=add(out,term)
    return out
def normalized(p):
    den=reduce(lcm,(c.denominator for c in p.values()),1)
    common=reduce(gcd,(abs(int(c*den)) for c in p.values()),0)
    return {m:c*den/common for m,c in p.items()}
old=json.loads(OLD.read_text());new=json.loads(NEW.read_text())
names={c['name']:c['id'] for c in old['coordinates']}
before={r['name']:read(r['terms']) for r in old['residuals']}
after={r['name']:read(r['terms']) for r in new['residuals']}
ss={};factors={};deleted=set();removed=set();incidence={}
for k in range(3):
    pre=f'detector{k}'
    b=names[pre+'.B']
    e,t,q,t2,q2,f=[names[pre+'.normalized.'+v] for v in ['scaled_e','s','q','s2.quadratic','q2.quadratic','Bh.quadratic']]
    expected={
      pre+'.Bh.definition':add(add(atom(17,e),atom(-1,e,b)),atom(-17,t,f)),
      pre+'.q2.definition':add(atom(1,q,q),atom(-1,q2)),
      pre+'.secondConic':add(add(add(atom(17,b,q2),atom(867,f,f)),atom(-34,t,f)),atom(-1,t,t))}
    for name,p in expected.items():assert after[name]==p,name
    ss.update({f:atom(1,t,f),q:atom(1,t,q),q2:atom(1,t,t,q2),t2:atom(1,t,t)})
    factors[pre+'.q2.definition']=atom(1,t,t)
    factors[pre+'.secondConic']=atom(1,t,t)
    deleted.add(pre+'.s2.definition');removed.add(t2)
    assert sub(before[pre+'.secondConic'],{t:atom(0),t2:atom(0),q2:atom(1,q,q)})==add(atom(17,b,q,q),atom(867,f,f))
    zero={t:atom(0),f:atom(0),q:atom(0),q2:atom(0)}
    assert sub(after[pre+'.q2.definition'],zero)==sub(after[pre+'.secondConic'],zero)=={}
    assert sub(after[pre+'.Bh.definition'],zero)==sub(before[pre+'.Bh.definition'],{f:atom(0)})
    incidence[pre]={str(i):[name for name,p in before.items() if any(i in m for m in p)] for i in [f,q,q2,t2]}
assert set(after)==set(before)-deleted
for name,p in before.items():
    transformed=sub(p,ss)
    assert transformed==({} if name in deleted else times(factors.get(name,atom(1)),after[name])),name
assert {c['id'] for c in new['coordinates']}=={c['id'] for c in old['coordinates']}-removed
assert old['fixedParameter']==new['fixedParameter']
assert old['coordinates'][0]==new['coordinates'][0]
assert all(len([v for v in m if v!=-1])<=2 for p in after.values() for m in p)
total={}
for p in after.values():
    p=normalized(p)
    total=add(total,times(p,p))
assert total==read(json.loads(POLY.read_text())['terms'])
assert max(sum(v!=-1 for v in m) for m in total)==4
assert len({tuple(v for v in m if v!=-1) for m in total})==24712
assert reduce(gcd,(abs(c.numerator) for m,c in total.items() if -1 not in m),0)==1
assert {(m,c) for m,c in total.items() if m.count(-1)==2}=={((-1,-1,57,57),Q(16))}
report={'oldCoordinates':len(old['coordinates']),'newCoordinates':len(new['coordinates']),
        'oldRowsChecked':len(before),'newRows':len(after),'monomials':24712,'degree':4,
        'fullPolynomialMatch':True,'zeroBranchResidualChecked':True,'privateIncidence':incidence,
        'bindings':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [OLD,NEW,POLY]}}
(HERE/'review-factored-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='privateIncidence'},indent=2))
