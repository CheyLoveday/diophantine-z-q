"""Seek guarded polynomial substitutions using already retained inverses."""
import macaulay_search as M
from search import *
import time

def affine_in(p,x):
    a={};b={}
    for (s,m),v in p.items():
        n=m.count(x)
        if n>1:return None
        if n==1:a[s,tuple(y for y in m if y!=x)]=v
        else:b[s,m]=v
    return a,b

def canon(p):
    a=p[min(p)]
    return {k:v/a for k,v in p.items()},a

def run():
    start=time.time();guards=[];attempts=[];success=[]
    for rid,p in c.rows.items():
        for y in C.variables(p):
            pair=affine_in(p,y)
            if pair is None:continue
            b,rest=pair
            if set(rest)!={(0,())}:continue
            if not rest[0,()] or C.degree(b)!=1:continue
            # y*b = -rest, hence b^{-1}=-y/rest.
            bc,scale=canon(b)
            inv={(0,(y,)):-scale/rest[0,()]}
            guards.append((rid,bc,inv))
    for x in sorted(c.coordinates,reverse=True):
        if x in c.protected:continue
        affected=c.incidence[x]
        for rid in sorted(affected):
            pair=affine_in(c.rows[rid],x)
            if pair is None:continue
            b,rest=pair
            if not b or C.degree(b)!=1:continue
            bc,scale=canon(b)
            for guard,gb,inv in guards:
                if guard in affected or bc!=gb or x in C.variables(inv):continue
                q=C.multiply({k:-v/scale for k,v in rest.items()},inv)
                reduced,complete,n=M.solve([q],affected)
                record={'coordinate':x,'pivot':rid,'guard':guard,'replacementDegree':C.degree(q),'replacementReductionMultiples':n,'replacementClosureComplete':complete,'replacementReduced':reduced is not None}
                attempts.append(record)
                if reduced is None:continue
                q,trace=reduced[0]
                others=sorted(affected-{rid})
                result,complete,n=M.solve([C.substitute(c.rows[r],x,q) for r in others],affected)
                record.update({'fullReductionMultiples':n,'fullClosureComplete':complete,'success':result is not None})
                if result is not None:
                    success.append({'coordinate':x,'pivot':rid,'guard':guard,'replacement':C.terms(q)})
                    print('FOUND',success[-1],flush=True)
    out={'seconds':time.time()-start,'guards':len(guards),'attempts':attempts,'success':success}
    (OUT/'inverse-search-report.json').write_text(json.dumps(out,indent=2)+'\n')
    print('guards',len(guards),'attempts',len(attempts),'successes',len(success),flush=True)
if __name__=='__main__':run()
