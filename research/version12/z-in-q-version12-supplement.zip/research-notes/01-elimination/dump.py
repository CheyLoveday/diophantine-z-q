from search import *
def fmt(p):
    return ' + '.join(str(a)+''.join('*S' for _ in range(s))+''.join('*'+str(v) for v in m) for (s,m),a in p.items())
for r,p in c.rows.items():
    print(r,c.meta[r]['name'],fmt(p))
