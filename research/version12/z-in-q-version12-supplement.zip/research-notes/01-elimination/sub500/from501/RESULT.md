# One exact norm-coordinate elimination

The frozen 501-coordinate system admits an exact reduction to 500 coordinates,
499 witnesses, 469 quadratic residuals, and a degree-four sum of squares with
24,732 monomials. Its primitive content is one and its largest coefficient is
`16*3^(2^26)`, with the unchanged fixed parameter `C=3^(2^25)`.

This result alone does not satisfy the user's threshold of fewer than 500
total variables. It is available to combine with independent reductions.
The author's standalone checks passed; separate acceptance remains required.

## Frozen source and outputs

The input is `10-combination/candidate501-ir.json`, copied here under the
historical search filename `baseline523.json`. The filename does not denote
its current coordinate count. Its SHA-256 is
`6a31040f85e30cc6f9d076bf6c92218be110e0829e93333d7e99f93a6b2f0d9a`.

The generated artifacts are:

| Artifact | SHA-256 |
| --- | --- |
| `candidate500-ir.json` | `2a3b9b0e320ae1d6ad3693674c05d66cd820648b6d0b16ab2511f439bb337e38` |
| `elimination500-certificate.json` | `dc9e0f8723c89fca2542af906059cc433006f6e8c8c410e38c15598e6bfdf8e2` |
| `polynomial500.json` | `13bc1f9229a8164836b4e051288e29439228b9b9307e631ac9b7baab4ef27312` |

## Exact identity and consumer coverage

Write `f(H)=a+b*sqrt(2)`. The new scalar block introduced coordinate 535,
`reduced_scalar.norm_fH`, with defining residual 505 giving

```text
q = a^2 - 2b^2.
```

Its only other consumer is residual 506, the constant-node equation. That
equation uses q only through q^2. The unchanged order-40 test already has
coordinates 311 and 312, with residuals 263 and 264 giving

```text
t = a^2 + 2b^2,     u = a*b.
```

Here coordinate 312 stores a*b, not the full sqrt(2)-coefficient 2a*b.
Therefore

```text
(a^2 - 2b^2)^2 = t^2 - 8u^2.
```

Replace the q^2 occurrence in residual 506 by `t^2-8u^2`, and delete coordinate
535 and residual 505. All residuals remain quadratic. The certificate records
the exact polynomial multiples of unchanged residuals 263 and 264 that prove
this replacement, including every rational scalar and sign.

For any old solution, forget q; the displayed identity proves the new row.
For any new solution, insert `q=a^2-2b^2`; the same identity proves the old
constant-node row and the defining row. These maps are mutual inverses and
fix every other coordinate, including the input. No denominator, inequality,
new arithmetic premise, exceptional branch, or choice of witnesses occurs.

The replacement touches no scalar reciprocal-chart coordinate. It also
touches no detector chain or normalized pole coordinate. It can be transported
to a later candidate if the four named rows and a,b,t,u retain their meanings.
Such transport still requires checking the exact rows and consumer incidence.

## Reproduction

From this directory, run:

```text
python -B macaulay_search.py 1200
python -B verify_result.py
```

The search is a bounded exact linear-algebra search over multiples of retained
quadratics. The standalone verifier imports neither the search nor the
compiler. It checks the frozen source hash, all affected-row coverage, the
constant pivot, every polynomial identity, the unchanged coordinates and
fixed parameter, and every coefficient in the newly expanded sum of squares.

The initial census found no direct substitution and no common affine
Hessian-kernel direction. The bounded retained-ideal search nevertheless
found the norm identity above. It found no second elimination in that pass.
The same identity was first found on the 504-coordinate predecessor and then
rederived and verified on the exact 501-coordinate input.
