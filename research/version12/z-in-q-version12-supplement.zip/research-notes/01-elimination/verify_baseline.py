"""Rebuild the unchanged primitive sum of squares and compare every term."""
from search import *
from math import gcd
from functools import reduce
import hashlib

REPO=OUT.parents[1]/'quartic-version6-release/repository'
TABLE=REPO/'quartics/quartic-523-540/final523_540/symbolic523/polynomial/polynomial.json'
MANUSCRIPT=REPO/'manuscripts/quartic_v11.tex'
c.normalize()
p=c.sum_of_squares()
table=json.loads(TABLE.read_text())
mapping={v['sourceId']:v['id'] for v in table['coordinates']}
remapped={(s,tuple(mapping[v] for v in m)):a for (s,m),a in p.items()}
assert remapped==C.polynomial(table['terms'])
assert C.variables(p)==set(c.coordinates)
assert C.degree(p)==4
assert all(a.denominator==1 for a in p.values())
# Distinct coordinate monomials can have several S coefficients. At the fixed
# S, a nonzero coefficient polynomial cannot vanish: S is larger than 1 plus
# the sum of the absolute lower coefficients divided by the leading integer.
by_monomial={}
for (s,m),a in p.items():by_monomial.setdefault(m,{})[s]=a
bound=max(sum(abs(a) for s,a in q.items() if s<max(q)) for q in by_monomial.values())
assert bound < 2**10000
# S=3^(2^26)>2^(2^26)>2^10000+1, so dominance proves specialization support.
result={'baselineSha256':C.digest(BASE/'baseline523.json'),
        'manuscriptSha256':C.digest(MANUSCRIPT),
        'tableSha256':C.digest(TABLE),
        'coordinates':len(c.coordinates),'witnesses':len(c.coordinates)-1,
        'quadraticResiduals':len(c.rows),'degree':C.degree(p),
        'formalTerms':len(p),'specializedMonomials':len(by_monomial),
        'maximumFormalIntegerCoefficientBits':max(abs(a.numerator).bit_length() for a in p.values()),
        'specializationDominanceBoundBits':bound.numerator.bit_length(),
        'coefficientTableExactlyMatched':True,
        'noDecimalExpansionOfS':True,
        'status':'No variable reduction found. This verifies the baseline only.'}
(OUT/'baseline-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
