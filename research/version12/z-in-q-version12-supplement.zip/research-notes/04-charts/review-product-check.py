"""Independent checks for the scalar replacement as literally present in 505.
No producer or other verifier is imported. Writes only beside this file.
"""
from pathlib import Path
from fractions import Fraction as F
import json, hashlib
HERE=Path(__file__).resolve().parent
WORK=HERE.parent
REPO=WORK.parent/'quartic-version6-release/repository'
paths={'baseline':REPO/'quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json',
       'depth':WORK/'03-depth/beta12/final/candidate-ir.json',
       'product':WORK/'06-product/candidate518-ir.json',
       'product_report':WORK/'06-product/REPORT.md',
       'combined':WORK/'10-combination/candidate505-ir.json',
       'manuscript':REPO/'manuscripts/quartic_v11.tex'}
raw={n:p.read_bytes() for n,p in paths.items()}
base,depth,product,combined=[json.loads(raw[n]) for n in ['baseline','depth','product','combined']]
def pol(ts):
    d={}
    for t in ts:
        k=(t.get('sPower',0),tuple(t['monomial']))
        d[k]=d.get(k,F(0))+F(t['coefficient'])
    return {k:v for k,v in d.items() if v}
def add(a,b,c=1):
    d=a.copy()
    for k,v in b.items():d[k]=d.get(k,F(0))+c*v
    return {k:v for k,v in d.items() if v}
def mul(a,b):
    d={}
    for (s,m),v in a.items():
        for (t,n),w in b.items():
            k=(s+t,tuple(sorted(m+n)));d[k]=d.get(k,F(0))+v*w
    return {k:v for k,v in d.items() if v}
def scale(a,c):return {k:v*c for k,v in a.items() if v*c}
def eqscale(a,b):
    assert set(a)==set(b)
    k=next(iter(a));ratio=a[k]/b[k]
    assert ratio and a==scale(b,ratio)
def var(i):return {(0,(i,)):F(1)}
one={(0,()):F(1)}
bn={c['id']:c['name'] for c in base['coordinates']}
dn={c['id']:c['name'] for c in depth['coordinates']}
cn={c['name']:c['id'] for c in combined['coordinates']}
cr={r['name']:pol(r['terms']) for r in combined['residuals']}
def remap(p,names):return {(s,tuple(sorted(cn[names[i]] for i in m))):v for (s,m),v in p.items()}
def value(n):return remap(pol(depth['values'][n]['terms']),dn)
removed_names={bn[i] for i in range(515,528)}
removed_rows={r['name'] for r in base['residuals'] if r['id'] in range(481,494)}
affected={r['name'] for r in base['residuals'] if any(bn[i] in removed_names for t in r['terms'] for i in t['monomial'])}
assert affected==removed_rows|{'scalar.W2.definition'}
assert not removed_names&set(cn)
scalar_same=[]
for r in depth['residuals']:
    if r['name'].startswith(('scalar.','Sscalar.')) and r['name'] not in removed_rows|{'scalar.W2.definition'}:
        eqscale(cr[r['name']],remap(pol(r['terms']),dn));scalar_same.append(r['name'])
def new(s):return var(cn['reduced_scalar.'+s])
q,A,U,V,V2,B,B2,W=[new(s) for s in ['norm_fH','constant_node','ratio_leaf0','ratio_leaf1','ratio_leaf1_squared','ratio_node','ratio_node_squared','root']]
r=value('scalar.r');f0=value('U0.f.0');f1=value('U0.f.1');z0=value('scalar.zRatio.0');z1=value('scalar.zRatio.1')
i32=var(cn['scalar.rInverse32.square.quadratic'])
expected={
'norm_fH':add(q,add(mul(f0,f0),mul(f1,f1),-2),-1),
'constant_node':add(mul(r,add(A,one,-1)),mul(q,q),-1),
'ratio_leaf0':add(U,mul(z0,i32),-1),
'ratio_leaf1':add(V,mul(z1,i32),-1),
'ratio_leaf1_squared':add(V2,mul(V,V),-1),
'ratio_node':add(B,add(mul(U,U),mul(r,V2)),-1),
'ratio_node_squared':add(B2,mul(B,B),-1),
'root':add(W,add(mul(A,A),mul(r,B2)),-1)}
for n,p in expected.items():eqscale(cr['reduced_scalar.'+n],p)
eqscale(cr['scalar.W2.definition'],add(value('scalar.W2'),mul(W,W),-1))
# The input inverse and its chain have their literal intended values.
ri=var(cn['scalar.rInverse'])
eqscale(cr['scalar.rInverse.definition'],add(mul(r,ri),one,-1))
chain=['scalar.rInverse32.'+'.'.join(['half']*n+['square']) for n in range(4,-1,-1)]
previous=ri
for name in chain:
    current=var(cn[name+'.quadratic'])
    eqscale(cr[name+'.definition'],add(mul(previous,previous),current,-1));previous=current
assert previous==i32
# Test normalized valuation implications without making a completeness claim.
valuation_cases=0
for rho in range(-19,20,2):
    for aq in range(-24,25):
        for uu in range(-24,25):
            for vv in range(-24,25):
                a=min(0,rho+2*aq);b=min(2*uu,rho+2*vv);w=min(2*a,rho+2*b)
                if rho+2*w>0:
                    assert rho>0 and aq+rho>=1 and 32*rho+uu>=32 and 32*rho+vv>=32
                valuation_cases+=1
result={'status':'passed','scope':'scalar replacement in candidate505; not whole-candidate arithmetic approval',
'hashes':{n:hashlib.sha256(b).hexdigest() for n,b in raw.items()},
'new_equations_checked':8,'old_scalar_rows_retained_checked':len(scalar_same),
'removed_coordinate_consumers_exact':True,'inverse32_chain_checked':True,
'valuation_regression_cases':valuation_cases}
(HERE/'review-product-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
