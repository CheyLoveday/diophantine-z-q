'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../quartic-version6-release/repository');
const input=path.join(repo,'quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json');
const text=fs.readFileSync(input,'utf8'),data=JSON.parse(text);
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const changes=[];
for(let i=0;i<5;i++){
 const names=[0,1].map(j=>`V${i}.dxInverse.${j}`);
 const ids=names.map(n=>data.coordinates.find(c=>c.name===n).id);
 const rows=[0,1].map(j=>data.residuals.find(r=>r.name===`V${i}.dxInverse.definition.${j}`));
 for(const r of data.residuals) if(r.terms.some(t=>t.monomial.some(v=>ids.includes(v))))
  if(!rows.includes(r))throw Error('inverse consumed outside guard');
 const kept=rows[0].terms.filter(t=>!t.monomial.includes(ids[1]));
 if(!kept.some(t=>t.monomial.includes(ids[0])))throw Error('missing rational denominator');
 changes.push({point:`V${i}`,oldCoordinates:ids,keptCoordinate:ids[0],removedCoordinate:ids[1],replacedRow:rows[0].id,removedRow:rows[1].id,oldRows:structuredClone(rows),newTerms:kept});
 rows[0].terms=kept;rows[0].name=`V${i}.dxRationalCoefficientInverse`;
 data.residuals=data.residuals.filter(r=>r!==rows[1]);
 data.coordinates=data.coordinates.filter(c=>c.id!==ids[1]);
 data.coordinates.find(c=>c.id===ids[0]).name=`V${i}.dxRationalCoefficientInverse`;
}
const artifact={format:'quadratic-residual-candidate-v1',sourceSha256:sha(text),coordinates:data.coordinates,residuals:data.residuals,changes};
const encoded=JSON.stringify(artifact,null,2)+'\n';
fs.writeFileSync(path.join(__dirname,'candidate-518.json'),encoded);
const summary={status:'candidate_requires_independent_arithmetic_acceptance',source:input,sourceSha256:sha(text),candidateSha256:sha(encoded),coordinates:data.coordinates.length,witnesses:data.coordinates.length-1,residuals:data.residuals.length,maxResidualDegree:Math.max(...data.residuals.flatMap(r=>r.terms.map(t=>t.monomial.length))),removedCoordinates:changes.map(c=>c.removedCoordinate),removedRows:changes.map(c=>c.removedRow)};
fs.writeFileSync(path.join(__dirname,'summary.json'),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
