"""Remove the unnecessary denominator square from the 504 scalar chart."""
from pathlib import Path
from fractions import Fraction as Q
from functools import reduce
from math import gcd,lcm
import json,hashlib
H=Path(__file__).resolve().parent
W=H.parent.parent
SOURCE=W/'10-combination/candidate504-ir.json'
DEPTH=W/'03-depth/beta12/final/candidate-ir.json'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pol(ts):return {(t.get('sPower',0),tuple(t['monomial'])):Q(t['coefficient']) for t in ts}
def terms(p):return [{'sPower':s,'monomial':list(m),'coefficient':str(v)} for (s,m),v in sorted(p.items()) if v]
def add(p,q,c=1):
 d=p.copy()
 for k,v in q.items():d[k]=d.get(k,0)+c*v
 return {k:v for k,v in d.items() if v}
def mul(p,q):
 d={}
 for (s,m),v in p.items():
  for (t,n),w in q.items():
   k=(s+t,tuple(sorted(m+n)));d[k]=d.get(k,0)+v*w
 return {k:v for k,v in d.items() if v}
def scale(p,q):return {k:v*q for k,v in p.items() if v*q}
def const(q):return {(0,()):Q(q)} if q else {}
def var(i):return {(0,(i,)):Q(1)}
def fc(a,b=0):return const(a),const(b)
def fa(p,q):return tuple(add(a,b) for a,b in zip(p,q))
def fs(p,q):return tuple(add(a,b,-1) for a,b in zip(p,q))
def fm(p,q):return add(mul(p[0],q[0]),mul(p[1],q[1]),2),add(mul(p[0],q[1]),mul(p[1],q[0]))
def fscale(p,q):return tuple(scale(a,q) for a in p)
def norm(p):
 den=reduce(lcm,(v.denominator for v in p.values()),1)
 num=reduce(gcd,(abs(int(v*den)) for v in p.values()),0)
 return scale(p,Q(den,num))
def write(n,o):(H/n).write_text(json.dumps(o,indent=2)+'\n')
d=read(SOURCE);depth=read(DEPTH)
assert sha(SOURCE)=='7c17debaff9a726562be6b7ef843dbc6ca6a0a9d17556158c54ffe5c49ddb0cd'
cn={c['name']:c['id'] for c in d['coordinates']};dn={c['id']:c['name'] for c in depth['coordinates']}
def val(s):return tuple({(pow,tuple(sorted(cn[dn[i]] for i in m))):v for (pow,m),v in pol(depth['values'][s+'.'+str(j)]['terms']).items()} for j in range(2))
def pv(s):return tuple(var(cn['scalar.shiftedS.reciprocal.'+s+'.'+str(j)]) for j in range(2))
a,b,D=fc(-1,Q(7,4)),fc(Q(39,8),Q(-9,2)),fc(11,-6)
c=fm(a,a);h,j,x=map(val,['S.h','S.j','S.x']);g,k=pv('g'),pv('k');dd=fa(fm(c,x),D)
# a*d*k + 2D*h + a*b*j - 2D*b*g = 0.
new=fs(fa(fa(fm(fm(a,dd),k),fscale(fm(D,h),2)),fm(fm(a,b),j)),fscale(fm(fm(D,b),g),2))
removed=[cn['scalar.shiftedS.reciprocal.d2.'+str(t)] for t in range(2)]
deleted=['scalar.shiftedS.reciprocal.d2.definition.'+str(t) for t in range(2)]
changed=['scalar.shiftedS.reciprocal.k.definition.'+str(t) for t in range(2)]
for r in d['residuals']:
 if r['name'] in changed:r['terms']=terms(new[changed.index(r['name'])])
d['residuals']=[r for r in d['residuals'] if r['name'] not in deleted]
d['coordinates']=[c for c in d['coordinates'] if c['id'] not in removed]
d['status']='candidate; exact scalar denominator-square cancellation; independent acceptance pending'
write('candidate502-ir.json',d)
total={}
for r in d['residuals']:total=add(total,mul(norm(pol(r['terms'])),norm(pol(r['terms']))))
assert len(d['coordinates'])==502 and len(d['residuals'])==471
assert max(len(m) for s,m in total)==4
assert {i for s,m in total for i in m}=={c['id'] for c in d['coordinates']}
write('polynomial502.json',{'fixedParameter':d['fixedParameter'],'terms':terms(total)})
stats={'variables':502,'witnesses':501,'residuals':471,'degree':4,'monomials':len(total),
 'sourceSha256':sha(SOURCE),'candidateSha256':sha(H/'candidate502-ir.json'),'polynomialSha256':sha(H/'polynomial502.json'),
 'removedCoordinates':removed,'deletedRows':deleted,'changedRows':changed,'independentAcceptance':'pending'}
write('certificate502.json',stats);print(json.dumps(stats,indent=2))
