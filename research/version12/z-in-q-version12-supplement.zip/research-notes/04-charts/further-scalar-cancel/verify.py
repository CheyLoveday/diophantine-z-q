"""Independent rational row-identity and SOS check; imports no producer."""
from pathlib import Path
from fractions import Fraction as F
from functools import reduce
from math import gcd,lcm
import json,hashlib
H=Path(__file__).resolve().parent;W=H.parent.parent
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(ts):return {(t.get('sPower',0),tuple(t['monomial'])):F(t['coefficient']) for t in ts}
def add(a,b,k=1):
 c=a.copy()
 for m,v in b.items():c[m]=c.get(m,0)+k*v
 return {m:v for m,v in c.items() if v}
def mult(a,b):
 c={}
 for (s,m),v in a.items():
  for (t,n),w in b.items():
   key=(s+t,tuple(sorted(m+n)));c[key]=c.get(key,0)+v*w
 return {m:v for m,v in c.items() if v}
def scale(a,k):return {m:v*k for m,v in a.items() if v*k}
def const(k):return {(0,()):F(k)} if k else {}
def var(i):return {(0,(i,)):F(1)}
def fc(a,b=0):return const(a),const(b)
def plus(a,b):return tuple(add(x,y) for x,y in zip(a,b))
def minus(a,b):return tuple(add(x,y,-1) for x,y in zip(a,b))
def times(a,b):return add(mult(a[0],b[0]),mult(a[1],b[1]),2),add(mult(a[0],b[1]),mult(a[1],b[0]))
def fs(a,k):return tuple(scale(x,k) for x in a)
def eqscale(a,b):
 assert set(a)==set(b)
 m=next(iter(a));k=a[m]/b[m];assert k and a==scale(b,k)
def replace(p,v,q):
 out={}
 for (s,m),c in p.items():
  term={(s,tuple(x for x in m if x!=v)):c}
  for i in range(m.count(v)):term=mult(term,q)
  out=add(out,term)
 return out
def norm(p):
 d=reduce(lcm,(v.denominator for v in p.values()),1)
 g=reduce(gcd,(abs(int(v*d)) for v in p.values()),0)
 return scale(p,F(d,g))
source=W/'10-combination/candidate504-ir.json';target=H/'candidate502-ir.json'
old,new=load(source),load(target);depth=load(W/'03-depth/beta12/final/candidate-ir.json')
assert sha(source)=='7c17debaff9a726562be6b7ef843dbc6ca6a0a9d17556158c54ffe5c49ddb0cd'
cn={c['name']:c['id'] for c in old['coordinates']};dn={c['id']:c['name'] for c in depth['coordinates']}
def val(s):return tuple({(t,tuple(sorted(cn[dn[x]] for x in m))):v for (t,m),v in read(depth['values'][s+'.'+str(j)]['terms']).items()} for j in range(2))
def pv(s):return tuple(var(cn['scalar.shiftedS.reciprocal.'+s+'.'+str(j)]) for j in range(2))
a,b,D=fc(-1,F(7,4)),fc(F(39,8),F(-9,2)),fc(11,-6)
c=times(a,a);assert times(b,b)==minus(times(c,c),D)
h,j,x=map(val,['S.h','S.j','S.x']);g,k=pv('g'),pv('k');d=plus(times(c,x),D)
N=minus(times(a,j),times(b,h))
M=minus(fs(times(times(a,D),times(h,plus(x,c))),-2),times(b,times(j,minus(times(c,x),D))))
G=minus(times(d,g),N);K=minus(times(times(d,d),k),M)
L=minus(plus(plus(times(times(a,d),k),fs(times(D,h),2)),times(times(a,b),j)),fs(times(times(D,b),g),2))
assert times(d,L)==minus(times(a,K),fs(times(times(D,b),G),2))
oldrows={r['name']:read(r['terms']) for r in old['residuals']};newrows={r['name']:read(r['terms']) for r in new['residuals']}
drop={'scalar.shiftedS.reciprocal.d2.definition.'+str(i) for i in range(2)}
change={'scalar.shiftedS.reciprocal.k.definition.'+str(i) for i in range(2)}
removed={cn['scalar.shiftedS.reciprocal.d2.'+str(i)] for i in range(2)}
assert {name for name,p in oldrows.items() if any(removed.intersection(m) for s,m in p)}==drop|change
assert set(newrows)==set(oldrows)-drop
for name,p in newrows.items():
 if name not in change:assert p==oldrows[name]
for i in range(2):
 eqscale(newrows['scalar.shiftedS.reciprocal.k.definition.'+str(i)],L[i])
 eqscale(oldrows['scalar.shiftedS.reciprocal.g.definition.'+str(i)],G[i])
 prior=oldrows['scalar.shiftedS.reciprocal.k.definition.'+str(i)]
 for j in range(2):prior=replace(prior,cn['scalar.shiftedS.reciprocal.d2.'+str(j)],times(d,d)[j])
 eqscale(prior,K[i])
assert {c['id'] for c in new['coordinates']}=={c['id'] for c in old['coordinates']}-removed
total={}
for p in newrows.values():
 assert max(len(m) for s,m in p)<=2
 total=add(total,mult(norm(p),norm(p)))
assert read(load(H/'polynomial502.json')['terms'])==total
assert len(new['coordinates'])==502 and len(newrows)==471 and len(total)==24670
assert max(len(m) for s,m in total)==4
assert {v for s,m in total for v in m}=={c['id'] for c in new['coordinates']}
assert total[(2,(57,57))]==16
assert [(s,m) for s,m in total if s==2]==[(2,(57,57))]
assert max(abs(v.numerator).bit_length() for (s,m),v in total.items() if s==0)<2048
assert max(abs(v) for (s,m),v in total.items() if s==1)<=48
assert any(s==0 and v==1 for (s,m),v in total.items())
out={'verified':True,'sourceSha256':sha(source),'candidateSha256':sha(target),'polynomialSha256':sha(H/'polynomial502.json'),
 'variables':502,'witnesses':501,'residuals':471,'degree':4,'monomials':24670,'content':1,
 'largestCoefficient':'16*3^(2^26)','fieldRowIdentity':True,'removedCoordinateConsumersChecked':True,
 'scope':'Exact algebraic checks; independent source acceptance is separate.'}
(H/'VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
