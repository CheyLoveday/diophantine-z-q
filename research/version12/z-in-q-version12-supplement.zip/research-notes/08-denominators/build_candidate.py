"""Build a 521-coordinate proposed system from the frozen 523-coordinate IR.

Algebraic identities and the extended-domain argument are documented separately.
This script verifies the mechanical row replacement and expands its quartic SOS.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import gcd,lcm
from functools import reduce
import json, hashlib, importlib.util

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[1]/'quartic-version6-release'/'repository'
SOURCE=REPO/'quartics/quartic-523-540/final523_540/symbolic523/integer-candidate-ir.json'
spec=importlib.util.spec_from_file_location('verifier',REPO/'quartics/quartic-523-540/final523_540/verify_elimination.py')
V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)
data=json.loads(SOURCE.read_text()); old=json.loads(SOURCE.read_text())
rows={r['name']:r for r in data['residuals']}
def C(v):return {(0,()):Q(v)} if v else {}
def sc(p,v):return {m:c*Q(v) for m,c in p.items() if c*v}
def sub(p,q):return V.add(p,sc(q,-1))
def F(a,b=0):return (C(a),C(b))
def fa(x,y):return tuple(V.add(x[i],y[i]) for i in range(2))
def fs(x,y):return tuple(sub(x[i],y[i]) for i in range(2))
def fm(x,y):return (V.add(V.mul(x[0],y[0]),sc(V.mul(x[1],y[1]),2)),V.add(V.mul(x[0],y[1]),V.mul(x[1],y[0])))
def fsc(x,v):return tuple(sc(p,v) for p in x)
def val(name):return tuple(V.readpoly(data['values'][name+'.'+str(i)]['terms']) for i in range(2))
next_id=max(c['id'] for c in data['coordinates'])+1
next_row=max(r['id'] for r in data['residuals'])+1
added=[];removed_ids=set();removed_rows=set();changed=[]
def fresh(name):
    global next_id
    coord={'id':next_id,'name':name,'kind':'gate','protected':False,'block':'reciprocal_fixed_difference'}
    data['coordinates'].append(coord);added.append(coord)
    next_id+=1
    return {(0,(coord['id'],)):Q(1)}
def freshF(name):return (fresh(name+'.0'),fresh(name+'.1'))
def addrow(name,p):
    global next_row
    assert V.degree(p)<=2
    data['residuals'].append({'id':next_row,'name':name,'kind':'structural','block':'reciprocal_fixed_difference','terms':V.terms(p)})
    next_row+=1
def change(name,p):
    assert V.degree(p)<=2
    rows[name]['terms']=V.terms(p);changed.append(name)
def eqF(name,p):
    for i in range(2):addrow(name+'.'+str(i),p[i])

D=F(11,-6);a=F(-1,Q(7,4));b=F(Q(39,8),Q(-9,2));c=fm(a,a)
for prefix,input_point,fname,outname,mode in [('V0','H','V0.f','logV0','log'),('scalar.shiftedS','S','Sscalar.f','Sscalar.z','z')]:
    old_prefixes=tuple(prefix+'.'+s for s in ['dxInverse','slope','slopeSquare','yProduct'])
    removed_ids.update(cc['id'] for cc in data['coordinates'] if cc['name'].startswith(old_prefixes))
    removed_rows.update(r['id'] for r in data['residuals'] if r['name'].startswith(old_prefixes))
    h,j,x=val(input_point+'.h'),val(input_point+'.j'),val(input_point+'.x')
    d=fa(fm(c,x),D)
    N=fs(fm(a,j),fm(b,h))
    M=fsc(fa(fsc(fm(fm(a,D),fm(h,fa(x,c))),2),fm(b,fm(j,fs(fm(c,x),D)))),-1)
    g=freshF(prefix+'.reciprocal.g');d2=freshF(prefix+'.reciprocal.d2');kk=freshF(prefix+'.reciprocal.k')
    eqF(prefix+'.reciprocal.g.definition',fs(fm(d,g),N))
    eqF(prefix+'.reciprocal.d2.definition',fs(d2,fm(d,d)))
    eqF(prefix+'.reciprocal.k.definition',fs(fm(d2,kk),M))
    f=val(fname)
    frows=fs(f,fm(g,g))
    for i in range(2):change(fname+'.definition.'+str(i),frows[i])
    guard=fresh(prefix+'.reciprocal.f0Inverse')
    addrow(prefix+'.reciprocal.f0Inverse.definition',sub(V.mul(f[0],guard),C(1)))
    numerator=fm(g,val('logV0.polynomial')) if mode=='log' else g
    output=val(outname)
    outrows=fa(fm(kk,output),numerator)
    for i in range(2):change(outname+'.definition.'+str(i),outrows[i])
    for name,pair in [('g',g),('k',kk),('d2',d2)]:
        for i in range(2):data['values'][prefix+'.reciprocal.'+name+'.'+str(i)]={'terms':V.terms(pair[i]),'block':'reciprocal_fixed_difference'}

assert len(removed_ids)==16
data['coordinates']=[c for c in data['coordinates'] if c['id'] not in removed_ids]
data['residuals']=[r for r in data['residuals'] if r['id'] not in removed_rows]
data['values']={name:value for name,value in data['values'].items() if not (V.variables(V.readpoly(value['terms']))&removed_ids)}
data['guards']=[g for g in data['guards'] if g['name'] not in {'V0.dxInverse','V0.f','scalar.shiftedS.dxInverse','Sscalar.f'}]
data.pop('census',None)
data['variant']={'name':'proposed_521_reciprocal_fixed_differences','status':'exact_algebra_checked_arithmetic_domain_review_required','parentSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest()}
polynomial={}
for row in data['residuals']:
    p=V.readpoly(row['terms'])
    assert V.degree(p)<=2 and not V.variables(p)&removed_ids
    den=reduce(lcm,(q.denominator for q in p.values()),1)
    num=reduce(gcd,(abs(q.numerator*(den//q.denominator)) for q in p.values()),0)
    p=sc(p,Q(den,num));row['terms']=V.terms(p)
    polynomial=V.add(polynomial,V.mul(p,p))
assert len(data['coordinates'])==521
assert len(data['residuals'])==490
assert V.degree(polynomial)==4
assert all(q.denominator==1 for q in polynomial.values())
assert V.variables(polynomial)=={c['id'] for c in data['coordinates']}
dependent={m for (s,m) in polynomial if s}
unit_terms=[(s,m) for (s,m),q in polynomial.items() if s==0 and m not in dependent and abs(q)==1]
assert unit_terms
data['counts']={'coordinates':521,'residuals':490,'gates':0}
(OUT/'candidate-521-ir.json').write_text(json.dumps(data,indent=2)+'\n')
(OUT/'candidate-521-polynomial.json').write_text(json.dumps({'coordinates':data['coordinates'],'fixedParameter':data['fixedParameter'],'terms':V.terms(polynomial)},indent=2)+'\n')
report={'coordinates':521,'residuals':490,'degree':4,'monomials':len({m for (s,m) in polynomial}),'removedCoordinateIds':sorted(removed_ids),'addedCoordinates':added,'changedResiduals':changed,'integerCoefficients':True,'contentOverZ_S':reduce(gcd,(abs(q.numerator) for q in polynomial.values()),0),'fixedSContent':1,'sIndependentUnitCoefficients':len(unit_terms),'candidateSha256':hashlib.sha256((OUT/'candidate-521-ir.json').read_bytes()).hexdigest(),'qualification':'Exact local identities checked separately. Extension at Q=-P needs arithmetic consumption review before acceptance.'}
(OUT/'candidate-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='addedCoordinates'},indent=2))
