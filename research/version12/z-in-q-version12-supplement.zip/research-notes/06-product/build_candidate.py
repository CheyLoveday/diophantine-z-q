"""Build the 518-variable scalar norm candidate from the pinned 523-variable IR."""
import hashlib, json, importlib.util
from pathlib import Path
from fractions import Fraction as Q
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent/'quartic-version6-release/repository'
BASE=REPO/'quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json'
spec=importlib.util.spec_from_file_location('poly',REPO/'quartics/quartic-523-540/final523_540/verify_elimination.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
d=json.loads(BASE.read_text())
def var(i):return {(0,(i,)):Q(1)}
def scale(a,c):return {k:Q(c)*v for k,v in a.items() if c*v}
def sub(a,b):return p.add(a,scale(b,-1))
def val(n):return p.readpoly(d['values'][n]['terms'])
one={(0,()):Q(1)}
removed_coords=list(range(515,528))
removed_rows=[481,482,483,484,485,486,487,488,489,490,491,492,493]
d['coordinates']=[c for c in d['coordinates'] if c['id'] not in removed_coords]
d['residuals']=[r for r in d['residuals'] if r['id'] not in removed_rows]
newrows=[]
def new(i,name):
 d['coordinates'].append({'id':i,'name':name,'kind':'gate','protected':False,'block':'reduced_scalar_norm','sourceLines':[]})
 return var(i)
def row(i,name,poly):
 assert p.degree(poly)<=2
 newrows.append({'id':i+100,'name':name,'kind':'structural','block':'reduced_scalar_norm','sourceLines':[],'terms':p.terms(poly)})
r=val('scalar.r'); f0=val('U0.f.0');f1=val('U0.f.1');z0=val('scalar.zRatio.0');z1=val('scalar.zRatio.1');r32=var(499)
q=new(540,'reduced_scalar.norm_fH')
a=new(541,'reduced_scalar.constant_node')
u=new(542,'reduced_scalar.ratio_leaf0')
v=new(543,'reduced_scalar.ratio_leaf1')
v2=new(544,'reduced_scalar.ratio_leaf1_squared')
b=new(545,'reduced_scalar.ratio_node')
b2=new(546,'reduced_scalar.ratio_node_squared')
w=new(547,'reduced_scalar.root')
row(508,'reduced_scalar.norm_fH',sub(q,sub(p.mul(f0,f0),scale(p.mul(f1,f1),2))))
row(509,'reduced_scalar.constant_node',sub(p.mul(r,sub(a,one)),p.mul(q,q)))
row(510,'reduced_scalar.ratio_leaf0',sub(u,p.mul(z0,r32)))
row(511,'reduced_scalar.ratio_leaf1',sub(v,p.mul(z1,r32)))
row(512,'reduced_scalar.ratio_leaf1_squared',sub(v2,p.mul(v,v)))
row(513,'reduced_scalar.ratio_node',sub(b,p.add(p.mul(u,u),p.mul(r,v2))))
row(514,'reduced_scalar.ratio_node_squared',sub(b2,p.mul(b,b)))
row(515,'reduced_scalar.root',sub(w,p.add(p.mul(a,a),p.mul(r,b2))))
for rr in d['residuals']:
 if rr['id']==495:rr['terms']=p.terms(sub(val('scalar.W2'),p.mul(w,w)));rr['name']='reduced_scalar.root_squared'
d['residuals']+=newrows
# Retain only valid bookkeeping values and guards. All original residual guards remain.
d['values']={k:v for k,v in d['values'].items() if not (p.variables(p.readpoly(v['terms'])) & set(removed_coords))}
d['values']['reduced_scalar.root']={'terms':p.terms(w)}
d['sourceGates']=[];d['census']=[]
# This is a residual system, not a claimed gate program.
for c in d['coordinates']:
 c['kind']='input' if c['id']==0 else 'base'
d['counts']={'coordinates':len(d['coordinates']),'residuals':len(d['residuals'])}
d['variant']={'name':'scalar_norm_three_tests','status':'candidate_requires_independent_arithmetic_review','baselineSha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'removedCoordinates':removed_coords,'removedRows':removed_rows,'rewrittenRows':[495],'newRows':[x['id'] for x in newrows],'arithmeticProof':'REPORT.md'}
assert len(d['coordinates'])==518 and len(d['residuals'])==487
active=set().union(*(p.variables(p.readpoly(rr['terms'])) for rr in d['residuals']))
assert active=={c['id'] for c in d['coordinates']}
(HERE/'candidate518-ir.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d['counts']))


