import json
from pathlib import Path
p=Path('work/quartic-version6-release/repository/quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json')
d=json.loads(p.read_text())
print(d.keys())
for k in ['scalar.r','scalar.W','scalar.W2','U0.f.0','U0.f.1','scalar.zRatio.0','scalar.zRatio.1','scalar.rInverse32']:
 print(k,d.get('values',{}).get(k))
