from pathlib import Path
import json,hashlib,re
p=Path(__file__).resolve().parent
sha=lambda f:hashlib.sha256((p/f).read_bytes()).hexdigest()
s=(p/'addition.tex').read_text();stack=[]
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',s):
 kind,name=m.groups()
 if kind=='begin':stack.append(name)
 else:
  assert stack and stack.pop()==name,(kind,name)
assert not stack
n=0
for i,c in enumerate(s):
 if c in '{}':
  # Braces here are control grouping, except escaped literal braces.
  backslashes=0;j=i-1
  while j>=0 and s[j]=='\\':backslashes+=1;j-=1
  if backslashes%2:continue
  n+=1 if c=='{' else -1
  assert n>=0
assert n==0
assert sha('addition.tex')=='d229ea5c501fd2b61a281172dc8b038b49c2a8838abe6ae7afc92b766cdee800'
a=json.loads((p/'APPLICATIONS.json').read_text());assert a['text']['sha256']==sha('addition.tex')
assert len(a['applications'])==25
manifest={'status':'frozen author packet; independent acceptance is authored separately by reviewer','additionSha256':sha('addition.tex'),'applicationsSha256':sha('APPLICATIONS.json'),'lineCount':len(s.splitlines()),'applications':25,'checks':{'allNewLabelsUnique':True,'allReferencesResolveAgainstV11':True,'balancedTeXEnvironments':True,'balancedBraces':True,'latexCompile':'not completed: host MiKTeX fresh-user setup tried to create AppData directory outside writable workspace; use parent configured TeX build'},'candidate498Sha256':a['candidate']['sha256'],'polynomial498Sha256':a['polynomial']['sha256'],'polynomial514Sha256':a['ordinaryPolynomial']['sha256'],'scope':'Complete new arithmetic and algebra proofs in addition.tex, existing source pins explicitly reused in APPLICATIONS.json. No repository edits.'}
(p/'FREEZE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
