import json
from pathlib import Path
p=Path('work/quartic-version6-release/repository/docs/theorem-application-audit/sources.json')
d=json.loads(p.read_text())
print(type(d).__name__)
if isinstance(d,dict):print(d.keys())
print(json.dumps(d,indent=2)[-6000:])
