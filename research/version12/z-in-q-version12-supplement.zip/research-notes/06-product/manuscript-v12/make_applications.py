"""Author-created application inventory, not an independent acceptance record."""
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
R=P.parent.parent.parent/'quartic-version6-release/repository'
T=P.parent.parent/'10-combination'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=R/'manuscripts/quartic_v11.tex'; new=P/'addition.tex'
def locator(p,label):
 text=p.read_text();needle='\\label{'+label+'}'
 pos=text.index(needle);line=text.count('\n',0,pos)+1
 return {'path':str(p),'sha256':sha(p),'label':label,'line':line}
source_catalog=R/'docs/theorem-application-audit/sources.json'
sources={x['id']:x for x in json.loads(source_catalog.read_text())}
external={k:sources[k] for k in ['silverman','voight-quaternion']}
apps=[]
def app(id,kind,source,consumers,required,constructed,coverage,maps,identity,exceptions,affected,scope):
 apps.append({'id':id,'kind':kind,'source':source,'consumers':[locator(new,k) for k in consumers],
 'obligations':{'required_inputs':required,'constructed_inputs':constructed,'domain_and_index_coverage':coverage,'transition_maps_and_scalars':maps,'identity_of_consumed_object':identity,'exceptional_cases':exceptions,'affected_downstream_claims':affected,'source_version_and_conventions':'Use pinned sources and literal K=Q(sqrt(2)), P, coefficient basis, and valuations in subsec:v12-inputs. '+scope,'validation_and_acceptance_scope':'This inventory is authored with the TeX. Mathematical arguments are in the indicated consumers. Existing finite verifiers check stated polynomial identities/counts only. Independent review of this final text is pending.'}})
def oldsrc(*labels):return [locator(old,k) for k in labels]
def newsrc(*labels):return [locator(new,k) for k in labels]
def exsrc(k,location):return {'id':k,'location':location,'pinned_source':external[k]}
app('V12-EXT-FORMAL3','external',exsrc('silverman','IV §1; Example IV.2.2.3; Proposition IV.2.3(a)'),['lem:v12-anchor-coefficient'],
 'Integral Weierstrass equation over the local integer ring; parameter z=-x/y; multiplication by an integer has that integer as linear coefficient.',
 'Literal short curve over the unramified quadratic extension of Q3. Exact rational z(2P)/3 reduces to 2+rho.',
 'Every nonzero even s=2*3^k*u, k>=0, u any signed 3-unit integer is treated.',
 'Curve negation gives inverse -z, hence odd multiplication series. [3]z=3z+O(z^3) preserves leading residue after dividing by3^(r+1); [u]z multiplies it by u mod3.',
 'f([s]P)/3^(2k+2) is rho mod3, so the actual rho coefficient has exact valuation2+2v3(s).',
 'Negative u handled by negation; f0 may vanish, f1 cannot. Depth r>=1 makes 3r-(r+1)>=1.',
 'Single-coefficient anchor, exact allowed index subgroup, exceptional S=-P rejection.',
 'No minimal-model theorem is invoked.')
app('V12-EXT-FORMAL2','external',exsrc('silverman','IV §1; Example IV.2.2.3; Proposition IV.2.3(a)'),['lem:v12-anchor-coefficient'],
 'Integral formal group and closure of the positive-depth subgroup under integral multiplication.',
 'At the ramified place over2 use v(2)=1, v(rho)=1/2 and literal v(z(P))=3/2. Construct branch via w=z^3-D*z*w^2.',
 'All integral multiples of P, including all nonzero even scalar indices.',
 'v(f)>=0 and v(a+b*rho)=min(v2(a),v2(b)+1/2) force both rational coefficients2-integral.',
 'Actual coefficients f0,f1 of f([s]P), divided by C which is a2-unit.',
 'Bad reduction at2 is permitted; no assertion of minimality or good reduction is used.',
 'Equivalence of old two-coefficient and new one-coefficient anchors.',
 'This is the direct integral formal-group construction, not VII.2.2 for minimal equations.')
app('V12-EXT-LOG-MIX','external',exsrc('silverman','Proposition IV.5.5, Lemma IV.6.3, Theorem IV.6.4, pp.129-132'),['lem:v12-mixed-local'],
 'Complete local field, integral formal group, normalized logarithm; r>v(p)/(p-1) for isometry.',
 'Every consumed place has K_v/Qp unramified,p>76176,v(p)=1 and formal depth>=1.',
 'All primary and conjugate alternate places; inert places use their single conjugation-stable valuation.',
 'Exact full ratios are u_i/h and (u_i-n_i)/(h-1); unit truncating factors preserve these valuations before depth is deduced.',
 'The literal L_i,L_i-prime of eq:v12-ratios, with numerator ell12 only for i=1 and denominator ell40 for all.',
 'One of h,h-1 is a unit; cross congruence transfers integrality first. No division by a possibly nonunit h or h-1 in the congruence subtraction.',
 'Local input order12, Lucas order40.',
 'Tail error comes from the manuscript recurrence, not a stronger unstated Silverman conclusion.')
app('V12-EXT-LOG-SCALAR','external',exsrc('silverman','Proposition IV.5.5, Lemma IV.6.3, Theorem IV.6.4, pp.129-132'),['lem:v12-scalar-sound'],
 'The same normalized homomorphic/isometric formal logarithm on positive depth.',
 'Norm(f(H)) positive valuation supplies one unramified place where H is formal. Exact duplication puts [2]R in its formal group, even if R reduces to(0,0).',
 'Every consumed rational prime; only one place above each prime is needed. Both signs of v(x(R)) are proved.',
 '[h]([2]R)=[2s]H gives v_p(h)+v(z([2]R))=v_p(s)+v(z(H));2 is a p-unit.',
 's=a-1, the scalar index actually consumed by the anchor and height theorem, not a.',
 'H and[2]R nontorsion and nonidentity; s,h nonzero; duplication numerator/denominator nonzero when v(x(R))!=0.',
 'M5(beta)^32 divides s and h(beta)<=H|s|^(19/32).',
 'The one-place norm implication is weaker than simultaneous local integrality and is used only here.')
app('V12-EXT-LOG-DEPTH','external',exsrc('silverman','Theorem IV.6.4, p.132, with Proposition IV.5.5 and Lemma IV.6.3'),['subsec:v12-completeness'],
 'Formal logarithm isometry at unramified odd p and starting depth>=1.',
 'Multiplication by primary doubling-image order puts P into formal group; h has extra factor p^19.',
 'All selected primary primes and all U_i=[h*n_i]P, with fixed integral root labels.',
 'Multiplication by p^19 adds19 to logarithm valuation and hence parameter valuation.',
 'H,U_i have depth>=20; relative parameter error>=80.',
 'Opposite points need only depth1; no simultaneous p divisibility of h and h-1 is assumed.',
 'Completeness of mixed test list.',
 'Exact same map as V9-LOG-DEPTH, applied to the unchanged CRT output.')
app('V12-EXT-QUATERNION','external',exsrc('voight-quaternion','Corrected online edition v1.0.7u, August5,2026; Proposition14.6.7, pp.223-224; ramification classification Main Theorem14.6.1'),['eq:v12-quaternion-criterion','eq:v12-anchor'],
 'Quadratic embedding into quaternion algebra(2,3)_Q, which ramifies exactly at2 and3; nonzero quadratic radicand.',
 't=f1/C; radicand1-2/(3*t^2) when t!=0; local square tests explicitly made at2 and3.',
 'All rational t: t=0 is separately solved by(0,0,1); a rational-square radicand is excluded by the division-algebra criterion.',
 'Multiply representation by3*t^2, then scale three witnesses by C and translate w_old=w+C.',
 'Exactly f1/C in Z_(2) intersect Z_(3), encoded by u^2+6v^2-2w^2-4Cw-3f1^2=0.',
 't^2=2/3 impossible overQ; local unit/positive/negative valuation cases listed. No further primes added.',
 'New anchor and unchanged scalar subgroup.',
 'New text cites the existing precise key voight-quaternion, not the different Chapter43 locator in voight2021. Existing corrected-online-version qualification retained; no equivalence to printed pagination asserted.')
app('V12-INT-POINTS','internal',oldsrc('subsec:v5-point-source','lem:v5-point-domains','v9:prop:odd-chart'),['subsec:v12-inputs','subsec:v12-reciprocal','subsec:v12-completeness'],
 'Literal normalized curve/generator; point charts and odd-coset equations.',
 'All nine old chart points retained; root labels n,a,t,b odd; scalar R is the literal difference S-P.',
 'All four roots and five comparison points covered; signs of chart h,j retained.',
 'Identity on retained charts; reciprocal chart separately checked for R.',
 '2E(K)=ZP; nonidentity labels; x,y nonzero on retained charts.',
 'S=P excluded by g guard; S=-P treated and then excluded by anchor; not assumed away.',
 'Every arithmetic step using integer labels and nonzero coordinates.',
 'No new Mordell-Weil or generator assertion.')
app('V12-INT-TRUNCATION','internal',oldsrc('lem:quartic-reciprocal-log','lem:v5-unramified-log'),['subsec:v12-mixed','lem:v12-mixed-local'],
 'Formal point at unramified p>76176; recurrence a0=1,a1=-2/5,a_j=(4j-5)/(4j+1)*a_(j-1).',
 'G2 for V1 andG9 for V0,V2,V3,V4; all primary factors replaced by1 at eventual depth20.',
 'First omitted index3 or10; small coefficient denominators and large-index factorial bounds explicitly controlled.',
 'Unit G factors preserve valuations; integrality converts relative12/40 errors to absolute ones; primary error80.',
 'Exact mixed ratios, not a common-order approximation substituted silently.',
 'Integrality is transferred before requiring depth20 on U_i. Denominator ell40(V0) and original nonzero guard remain.',
 'Lemma:v12-mixed-local and both final height contradictions.',
 'The unramified proof is applied at12/40; source statement values alone are not mechanically relabelled.')
app('V12-INT-DETECTOR','internal',oldsrc('eq:v5-detector-data','lem:v5-one-place','hyp:o8-pole'),['subsec:v12-mixed','subsec:v12-soundness','subsec:v12-completeness'],
 'Sixteen field tests with positive integral orders and original weight/pole domains; five-contact detector.',
 'Orders are9 tests at1,2 at12,5 at40; scales unchanged; product equals grouped degree9,2,5 polynomials.',
 'Every test listed exactly once; scalar pole retained separately.',
 'q_m=e^(2m-2)q1 follows from original R=e^-1/delta and test normalization. Grouping uses polynomial distributivity.',
 'Original product W and detector pole input preserved as functions for these new orders.',
 'All original w0,weight and pole guards remain; zero pole witness values are allowed.',
 'Contact radical divisibility and existence of detector pole witnesses.',
 'Pole realization estimates remain lambda^-3 and3nu+(10m-8)eta-2c for fixedm=1,12,40.')
app('V12-INT-PRODUCTHEIGHT','internal',oldsrc('v9:cor:scales','v9:eq:height-transfer'),['eq:v12-height-input','subsec:v12-soundness'],
 'Four odd root labels; three original positive rational square scales; nonzero integer N divisible by kth powers of all three radicals.',
 'Odd charts retained; tests givek=40 forF andk=12 for numerator(n-beta).',
 'Four root heights and both distinct nonzero-integer applications checked.',
 'Identity on productC and scales; retain B^2-6<7H|N|^(19/k).',
 'Maximum of actual labels n,a,t,b with sameH19.',
 'No field norm replaces the product height; F=0 and N=0 treated by stopping the respective contradiction.',
 'Forces Lucas equation and n=beta.',
 'H<2^2093966 and unchanged normalization of absolute height.')
app('V12-INT-HALFTRACE','new bridge',oldsrc('lem:v5-two-reductions','subsec:v9-completeness','subsec:v9-deep-completeness'),['subsec:v12-guards','subsec:v12-completeness'],
 'Split contact primes with oriented primary/opposite reductions; roots fixed before prime cutoff.',
 'U0=[h]P,Q0=P;Ui=[h*n_i]P,Qi=[n_i]P fori=1..4. Cutoff additionally excludes root denominator primes.',
 'All five differences at the same selected split prime, includingi=0.',
 'v(d_i)<0 andbarv(d_i)>=0; conjugation exchanges places, so2A_i=d_i+bar(d_i)!=0.',
 'A_i is the actual rational coefficient of the same subtraction denominator d_i.',
 'Trace-zero old assignments intentionally excluded; integer completeness supplies nonzero traces; soundness restores full inverse(A,-B)/(A^2-2B^2).',
 'Five-variable saving, retained subtraction domains.',
 'This is arithmetic guard strengthening, not equality of all old assignments.')
app('V12-INT-ANCHOROLD','new bridge',oldsrc('subsec:o8-anchor-subgroup','lem:v5-three-witness-anchor','lem:v9-bridge'),['lem:v12-anchor-coefficient','eq:v12-anchor-subgroup'],
 'Nonzero even scalar index and exact normalized P; old anchor means bothf0/C,f1/C semilocally integral.',
 's=a-1 even from odd chart; C=3^(2^25); actualR=S-P.',
 'Every signed even index via2*3^k*u; exact leading directionrho handled.',
 'f1 has minimal3-valuation and both coefficients2-integral; replace pair condition byf1/C alone.',
 'Exactly s in2*3^(2^24-1)Z excluding0, with same large height margin.',
 'f0 may vanish; f1 cannot. Private quaternion witnesses may change and are not claimed unique.',
 'Anchor equivalence, scalar reciprocal exceptional rejection, height constants.',
 'Source exponent is recalculated at2^25, not copied from older2^26 anchor.')
app('V12-INT-SCALARCONTACT','new bridge',oldsrc('v5:scalar32-bridge','lem:v9-bridge','hyp:o8-pole'),['subsec:v12-scalar','lem:v12-scalar-sound'],
 'r nonzero; consumed primes have oddv_p(r); finite correction is a unit atp>76176; nonzero pole inputcrW^2.',
 'Samebeta=2X^2+3 andcontactr; new constant-left four-leaf tree; original inverse and pole preparation retained.',
 'Every consumed rational prime; rho<0 excluded before positive descent; zero summands assignedinfinity.',
 'Opposite-parity valuations yield q>0 and ratio coefficients>=32; norm supplies one suitable place; duplication/log then givesp^32|s.',
 'Exactly M5(beta)^32|a-1, the old scalar conclusion.',
 'beta=2401 would forceX^2=1199; R nearT0 handled by doubling; no false inference that R itself formal.',
 'Same scalar height estimate, five-variable scalar saving.',
 'The new tree is not claimed algebraically equal to the oldW.')
app('V12-INT-SCALARHEIGHT','internal',oldsrc('thm:quartic-height19','lem:v9-bridge'),['lem:v12-scalar-sound','subsec:v12-soundness'],
 'OriginalH19 five-contact height theorem andM5(beta)^32|s withs nonzero.',
 'Previousnewlemma supplies that exactdivisibility; beta remains same input label.',
 'All rationalX allowed until final integer conclusion.',
 'h(beta)<=H*M5(beta)^19<=H|s|^(19/32).',
 'h(beta) is the absolute logarithmic height of2X^2+3.',
 'No reduction of order32 or replacement by a new height conjecture.',
 'Inequalitiesh(beta)<|a|/40 and finalN contradiction.',
 'Inherited theorem and its qualifications remain unchanged.')
app('V12-INT-SCALARCOMPLETE','new bridge',oldsrc('v5:scalar32-bridge','lem:original-seven-simultaneous-realization'),['subsec:v12-scalar','subsec:v12-completeness'],
 'IntegralX, choice of finite correction c, arbitrarily divisible h0 then s; old leaves integral onr-support and divisible onc-support outside r.',
 'Use those stronger old choices; q=Norm(fH) then q/r integral, new ratioleaves unchanged.',
 'All finite supportcr, including2,3,17; whole nonconstant scalar function controlled by continuity.',
 'NewW congruent1 on supportcr; newb=crW^2 has originallocal squareclasses and square reduceddenominator; invoke fresh pole witnesses.',
 'Pole predicate applied to actual newb, not oldscalarb.',
 'r may be negative but crpositive; W nonzero byunitcalculation; old pole witnesses not blindly retained.',
 'Scalar completeness compatible withanchorandglobalCRT.',
 'Uses same seven-prime squareclass basis and finite support.')
app('V12-INT-PRIMES','internal',oldsrc('thm:v5-simultaneous-primes','lem:v5-two-reductions','v9:lem:separation','subsec:v9-deep-completeness','v5:real-progression-bridge'),['subsec:v12-completeness'],
 'Roots/scales/continuitymodulusfixed; permittedfiniteprimeexclusions; orientedorders andprimeseparation.',
 'Samefixedroots/scales; enlargedcutoffforfivedenominators; newscalar/mixedfunctions givefiniteL with64|L.',
 'Allcontactformsandraysretained; allselectedprimespastfixedcutoff.',
 'CRT h=0modPi^19Mminus,h=1modMplus,h=h0modL withgcdconditions shown; realprogressionchooseslargepositiveh.',
 'One commonh used byeverymodule, not separately constructedwitnesssets.',
 'No selectedprime divides oppositeorder; pi coprimeL; traceguards require splits only in completeness. h avoids finiteforbiddenloci.',
 'Simultaneouscompletenessofallchanges.',
 'Hasse is not newly applied: the existing separationlemma, with its pinnedV9-HASSE-SEPARATION application, is reused unchanged.')
app('V12-INT-LUCAS','internal',oldsrc('lem:o8-lucas','subsec:v9-completeness'),['subsec:v12-soundness','subsec:v12-completeness'],
 'IntegerF(a,t,b)=0, nonzerob, large|a| forheight lowerbound; recurrence forpositivecompletenesslabels.',
 'SoundnessforcesF=0andpointQ4nonidentity givesb!=0; completenessusesa=s+1,spositive6-divisible.',
 'Signedsoundnesslabels andpositivecompletenesslabels separated.',
 'LowerboundlogB>|a|-3; recurrenceU_jmod(a-2)andmod2givesintegraloddb,t.',
 'The sameactualn,a,t,b enterF,heightB,androotpoints.',
 'No divisionbyzero:a-2positive incompleteness; nonzerobinsoundness.',
 'Finalheightcontradiction and allintegerwitnesses.',
 'No new recurrence or exponential-growth theorem is assumed.')
# Exact algebra bridges are recorded separately from arithmetic theorem applications.
for id,src,consumer,required,mapping,exception,downstream in [
 ('POLE',oldsrc('eq:v5-zero-pole'),'subsec:v12-poles','Original seven pole equations and unchangedw0/n/b guard rows.','Displayedpowersofb identify oldrows asb^2or b^4timesnewrows;restoreu2=b^2.','b!=0 provedfromw0 inverseandirrationalitysqrt2; allotherpolewitnessesmayvanish.','Threevariablesremoved; samepoleinput.'),
 ('RECIPROCAL',newsrc('eq:v12-anchor','lem:v12-anchor-coefficient'),'subsec:v12-reciprocal','Incomingchartx=h^2,j^2=x^2-D andliteralfixedP.','g=N/d,k=M/d^2,f=g^2,z=-g/k; ordinarydifferenceidentities andbothx=cbranchesproved.','dpositivebothrealembeddings;k!=0bynorm7obstruction;g0guard;S=Pexcluded;S=-PactualR=-2Pthenanchorcontradiction.','Actualf(R),z(R)preserved; onevariableinitialsaving.'),
 ('DCANCEL',newsrc('eq:v12-reciprocal-identities'),'eq:v12-dcancel','a_*^2=c_*,b_*^2=c_*^2-D; d!=0.','dL=a_*K0-2Db_*G; forwarddividebyd,reversebya_*,uniqued2=d^2.','a_*nonzeroNorm=-41/8; inheriteddnonzero.','Twomoreprivatecoordinatesremoved.'),
 ('TORIC',oldsrc('eq:v5-detector-data'),'subsec:v12-toric','RetainedQ=q^3,T=q12^2 andalloutsideconsumers; e*qdomains.','SevenquadraticsforceexactLaurentmonomials; restoreoldsixpowers; q12andq40unchanged.','ealpha=1ande=qdelta^3forcee,qnonzero; gamma,Q,vnonzerobeforedividing.','Threeprivatepowercoordinatesremoved.'),
 ('NORMSQUARE',newsrc('eq:v12-scalar-eight'),'subsec:v12-norm-elim','Retainedt=h0^2+2h1^2,u=h0h1; qonlyconsumedbysquare.','q^2=t^2-8u^2; dropqandrestoreuniqueq=h0^2-2h1^2.','No divisions or additionaldomains; factor8checkedagainsthalf-coefficientnormalization.','Onecoordinateeliminated; arithmeticnormproofusablebyreinsertion.'),
 ('COMPILE',oldsrc('subsec:v9-finite'),'subsec:v12-finite','Quadraticrawsystemandexactpivot/shearcertificates.','Constant-pivotsubstitutionwithuniqueinverse;invertibleshears; deletedprivateincidencechecked.','No variabledivisionintroduced bycompiler; inputprotected.','Exact519mixedprecursorandcombined498count.'),
 ('SOS',newsrc('subsec:v12-soundness','subsec:v12-completeness'),'subsec:v12-finite','467rationalquadraticresiduals in498coordinates.','Clear denominators/dividecontents independently;sumrational squaresvanishesiffallresidualsvanish.','Nonzerorationalnormalizationfactors only; allcoordinatesverifiedactive.','P498exactZ-in-Qprojection; degree4,count,content,coefficients.'),
 ('LIFT',newsrc('eq:v12-anchor'),'subsec:v12-finite','OnlyCdependenttermis-4Cw;Cfixed3^(2^25).','c0=3^1024,fifteensquaringsyieldc15=C;substituteinbilinearterm.','Unique rationalchain; nochoiceofsign fromequationsc_next=c_prev^2.','P514sameprojection,483residuals,24716monomials.')]:
 app('V12-ALG-'+id,'exact algebra bridge',src,[consumer],required,'Literal frozen498 data and equations displayedinTeX.','Fullprivatecoordinateincidencecheckedbyfrozenchaincertificates.',mapping,'Same retainedoutsidecoordinates andinput unless explicitly statedotherwise.',exception,downstream,'These identities are provedinTeX; finitechecks verify literalnormalizations/counts.')
# Every explicit inherited reference is accounted for either individually above or as scope/baseline metadata.
refs=set(re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',new.read_text()));newlabels=set(re.findall(r'\\label\{([^}]+)\}',new.read_text()))
payload={'schema':'author-application-inventory-v1','status':'awaiting independent review of final TeX; not an acceptance record',
 'text':{'path':str(new),'sha256':sha(new),'lineCount':len(new.read_text().splitlines())},
 'baselineManuscript':{'path':str(old),'sha256':sha(old)},
 'candidate':{'path':str(T/'candidate498-ir.json'),'sha256':sha(T/'candidate498-ir.json')},
 'polynomial':{'path':str(T/'polynomial498.json'),'sha256':sha(T/'polynomial498.json')},
 'ordinaryPolynomial':{'path':str(T/'polynomial514.json'),'sha256':sha(T/'polynomial514.json')},
 'existingSourceCatalog':{'path':str(source_catalog),'sha256':sha(source_catalog),'reuse':'Exact source records copied above; existing corrected-online and errata qualifications retained.'},
 'existingDependencyClosure':[{'path':str(R/x),'sha256':sha(R/x)} for x in ['docs/quartic-523-540/inventory.json','docs/quartic-523-540/new-applications.json','docs/quartic-523-540/README.md']],
 'externalSources':external,'applications':apps,
 'allExplicitInheritedReferences':[locator(old,k) for k in sorted(refs-newlabels)],
 'scopeReferences':{'thm:v9-quartics':'Baseline theorem, not a substitute for proving the changedcertificate.','sec:v9':'Inheritedconstruction scope.','subsec:v9-inputs':'Transitive arithmetic dependencies and qualificationclosure.'}}
(P/'APPLICATIONS.json').write_text(json.dumps(payload,indent=2)+'\n')
print(len(apps),'applications; text hash',sha(new))
