"""Polish the author inventory only; never modifies the frozen TeX."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent
p=P/'APPLICATIONS.json';d=json.loads(p.read_text())
replace={
 'Main Theorem14.6.1':'Main Theorem 14.6.1','August5,2026':'August 5, 2026','Proposition14.6.7':'Proposition 14.6.7',
 'one-place norm implication':'one-place norm implication','andG9':'and G9','3 or10':'3 or 10','All primary':'All primary','depth>=1':'depth >= 1','p>76176':'p > 76176',
 'givesp^32':'gives p^32','at2 and3':'at 2 and 3','at2':'at 2','at3':'at 3','at12/40':'at 12/40','theorem application':'theorem application',
 'ramifies exactly at2 and3':'ramifies exactly at 2 and 3','when t!=0':'when t != 0','by3*t^2':'by 3*t^2','three witnesses by C':'three witnesses by C',
 'corrected-online-version':'corrected online version','2-integral':'2-integral','coefficients2-integral':'coefficients 2-integral',
 'withs nonzero':'with s nonzero','fori=1..4':'for i=1,...,4','includingi=0':'including i=0','so2A_i':'so 2A_i','andbarv':'and barv',
 'bothf0':'both f0','actualR':'actual R','via2':'via 2','directionrho':'direction rho','minimal3-valuation':'minimal 3-valuation',
 'byf1':'by f1','in2*':'in 2*','excluding0':'excluding 0','at2^25':'at 2^25','older2^26':'older 2^26',
 'oddv_p':'odd v_p','atp >':'at p >','inputcrW':'input crW','Samebeta':'Same beta','andcontactr':'and contact polynomial r',
 'assignedinfinity':'assigned infinity','yield q>0':'yield v_p(q)>0','forceX':'force X','nearT0':'near T0','oldW':'old W',
 'OriginalH19':'Original H19','andM5':'and M5','Previousnewlemma':'The preceding new lemma','exactdivisibility':'exact divisibility',
 'rationalX':'rational X','of2X':'of 2X','order32':'order 32','Inequalitiesh':'Inequalities h','finalN':'final N',
 'IntegralX':'Integral X','onr-support':'on the support of r','onc-support':'on the support of c','ratioleaves':'ratio leaves',
 'supportcr':'support of cr','including2,3,17':'including 2, 3, and 17','NewW':'New W','congruent1':'congruent to 1','newb':'new b',
 'originallocal':'original local','reduceddenominator':'reduced denominator','oldscalarb':'old scalar b','crpositive':'cr positive',
 'byunitcalculation':'by the unit calculation','withanchorandglobalCRT':'with the anchor and global CRT',
 'changedcertificate':'changed certificate','Inheritedconstruction':'Inherited construction','qualificationclosure':'qualification closure',
 'beforedividing':'before dividing','sameP':'same P','literalnormalizations':'literal normalizations',
 'first omitted index3':'first omitted index 3','orderm':'order m','fixedm':'fixed m','at1,2 at12,5 at40':'at 1, two at 12, and five at 40',
 'Orders are9 tests':'Orders are nine tests','givek=':'give k=','fork=':'for k=','at12':'at 12','value32':'value 32','bothf':'both f',
 'Allcontact':'All contact','Q4nonidentity':'Q4 nonidentity','r-support':'r-support','c-support':'c-support'
}
for a in d['applications']:
 for k,s in a['obligations'].items():
  for old,new in replace.items():s=s.replace(old,new)
  a['obligations'][k]=s
by={a['id']:a['obligations'] for a in d['applications']}
by['V12-INT-PRIMES'].update({
 'required_inputs':'Roots, scales, and a continuity modulus are fixed before the prime choice. The inherited prime theorem allows finite exclusions and supplies oriented orders and prime separation.',
 'constructed_inputs':'The roots and scales are unchanged. The finite cutoff also excludes the five fixed abscissa denominators. The new scalar and mixed logarithm functions give a finite modulus L with 64 dividing L.',
 'domain_and_index_coverage':'All contact forms and prescribed ray classes are retained. Every selected prime exceeds the fixed cutoff.',
 'transition_maps_and_scalars':'Use h=0 modulo Pi^19*M_minus, h=1 modulo M_plus, and h=h0 modulo L. The displayed gcd conditions prove compatibility, and the real progression argument supplies a sufficiently large positive h.',
 'identity_of_consumed_object':'One common integer h supplies every module. The proof does not combine independently constructed witness sets.',
 'exceptional_cases':'No selected prime divides an opposite order; Pi is coprime to L. Split places are required for the guard-completeness argument only. The large h avoids every finite forbidden locus.',
 'affected_downstream_claims':'Simultaneous completeness of all replacements.',
 'source_version_and_conventions':'The literal field, generator, orientations, and normalized valuations are unchanged. Hasse is not newly applied: the existing separation lemma, with its pinned V9-HASSE-SEPARATION application, is reused.'})
by['V12-INT-LUCAS'].update({
 'required_inputs':'For the lower bound, integer labels satisfy F(a,t,b)=0, b is nonzero, and |a| is sufficiently large. Completeness uses the displayed integer recurrence.',
 'constructed_inputs':'Soundness forces F=0. The nonidentity point Q4 gives b nonzero. Completeness chooses a=s+1 with s positive and divisible by six.',
 'domain_and_index_coverage':'The argument treats signed soundness labels and positive completeness labels separately.',
 'transition_maps_and_scalars':'The inherited bound gives log B>|a|-3. The recurrence modulo a-2 and modulo two supplies integral odd b and t.',
 'identity_of_consumed_object':'The same actual labels n,a,t,b enter F, the height maximum B, and the four root points.',
 'exceptional_cases':'The denominator a-2 is positive in completeness. The label b is nonzero in soundness.',
 'affected_downstream_claims':'The final height contradiction and witnesses for every integer input.'})
alg={
 'POLE':('The original seven pole equations and unchanged w0, nu, and pole-input guard rows.', 'The displayed powers of the nonzero pole input identify each old row with its new row multiplied by its square or fourth power. Restore u2 as the square of the pole input.', 'The pole input is nonzero by the w0 inverse and irrationality of sqrt(2). Every other pole witness may vanish.', 'Three variables are removed; each pole input is unchanged.'),
 'RECIPROCAL':('The incoming chart x=h^2, j^2=x^2-D and the literal fixed point P.', 'Set g=N/d, k=M/d^2, f=g^2, z=-g/k. The ordinary difference identities and both branches with x=c are proved in the text.', 'The denominator d is positive at both real embeddings. The norm-seven obstruction gives k nonzero. The f0 guard gives g nonzero. S=P is excluded; S=-P gives the actual R=-2P and contradicts the anchor.', 'The actual f(R),z(R) are preserved, initially saving one variable.'),
 'DCANCEL':('a_*^2=c_*, b_*^2=c_*^2-D, and d nonzero.', 'Use dL=a_*K0-2Db_*G. Divide by d in the forward direction and by a_* in reverse, reinserting the unique d2=d^2.', 'a_* has nonzero norm -41/8, and d is already nonzero on the incoming chart.', 'Two further private coordinates are removed.'),
 'TORIC':('The retained Q=q^3 and T=q12^2 equations and every outside consumer; the e and q domains.', 'Seven quadratics force the displayed Laurent monomials. Restore the six old powers. The actual q12 and q40 outputs remain unchanged.', 'e*alpha=1 and e=q*delta^3 force e and q nonzero. Gamma, Q, and v are nonzero before each division.', 'Three private power coordinates are removed.'),
 'NORMSQUARE':('Retained t=h0^2+2h1^2 and u=h0*h1. The norm q is consumed only through its square.', 'Use q^2=t^2-8u^2; delete q and restore its unique value h0^2-2h1^2 in reverse.', 'No division or added domain restriction. The factor eight uses the actual half-coefficient normalization of u.', 'One coordinate is removed; reinsertion permits the arithmetic norm proof.'),
 'COMPILE':('The quadratic raw system and exact constant-pivot and shear certificates.', 'Each constant-pivot substitution has its unique polynomial inverse lift. Each linear shear is invertible. All deleted-coordinate incidences are checked.', 'The compiler introduces no variable division. The input coordinate is protected.', 'The exact 519-variable mixed precursor and combined 498-variable count.'),
 'SOS':('The 467 rational quadratic residuals in 498 coordinates.', 'Clear denominators and divide integer contents separately. Their rational squares sum to zero exactly when all residuals vanish.', 'All normalization factors are nonzero rationals. Every coordinate is verified active.', 'The exact Z-in-Q projection of P498, and its degree, count, content, and coefficients.'),
 'LIFT':('The only term involving C is -4*C*w in the anchor, with C=3^(2^25).', 'Start with c0=3^1024 and use fifteen successive squarings to obtain c15=C; substitute into the bilinear term.', 'The rational chain is unique. Equations c_next=c_prev^2 impose no choice of a square-root sign.', 'P514 has the same input projection, 483 residuals, and 24,716 monomials.')}
for key,(req,mapping,exc,affected) in alg.items():
 by['V12-ALG-'+key].update({'required_inputs':req,'constructed_inputs':'The literal frozen 498-variable data and equations displayed in the TeX.', 'domain_and_index_coverage':'The complete private-coordinate incidence is checked by the frozen chain certificates.', 'transition_maps_and_scalars':mapping,'identity_of_consumed_object':'Every retained outside coordinate and the input remain fixed unless the text explicitly states otherwise.', 'exceptional_cases':exc,'affected_downstream_claims':affected,'source_version_and_conventions':'The identities are proved in the TeX. Finite checks verify the literal normalizations and counts against the pinned source systems.'})
p.write_text(json.dumps(d,indent=2)+'\n')
print('Polished',len(d['applications']),'records; frozen TeX unchanged.')
