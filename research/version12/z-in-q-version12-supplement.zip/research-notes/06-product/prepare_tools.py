from pathlib import Path
p=Path(__file__).resolve().parent
root=p.parent.parent/'quartic-version6-release/repository/quartics/quartic-523-540/source-reproduction/tools'
for src,dst in [('compile_ir.py','compile_ir_s26.py'),('checker.cjs','checker_s26.cjs')]:
 s=(root/src).read_text().replace('2^27','2^26').replace('2**27','2**26').replace('134217728n','67108864n')
 (p/dst).write_text(s)
