import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));from search import *
d=json.loads(SRC.read_text());cs={c['id']:c for c in d['coordinates']}
for r in d['residuals']:
 if (r['name'].startswith('detector') and any(s in r['name'] for s in ['.B.definition','.p2.definition','.firstConic','.U2.definition','.Bh.definition','.s2.definition','.q2.definition','.secondConic'])):
  print(r['id'],r['name'],[(cs[v]['name'],v) for v in sorted(vs(read(r['terms'])))]);print(r['terms'])
