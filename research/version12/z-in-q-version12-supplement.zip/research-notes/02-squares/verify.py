"""Read-only verifier, independent of build.py and search.py.
Checks the exact pole substitution, retained nonzero guards, and whole SOS table.
The nonsquareness of 2 in Q and positivity of rational squares are used explicitly.
This is an algebraic equivalence check, not a proof of the baseline arithmetic.
"""
import json, hashlib, math, functools
from pathlib import Path
from fractions import Fraction
H=Path(__file__).resolve().parent
F=Fraction

def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def pol(terms):
 out={}
 for t in terms:
  m=tuple([-1]*t.get('sPower',0)+t['monomial'])
  assert m==tuple(sorted(m))
  out[m]=out.get(m,F(0))+F(t['coefficient'])
 return {m:c for m,c in out.items() if c}
def plus(a,b,k=F(1)):
 out=dict(a)
 for m,c in b.items():out[m]=out.get(m,F(0))+k*c
 return {m:c for m,c in out.items() if c}
def times(a,b):
 out={}
 for m,c in a.items():
  for n,d in b.items():
   z=tuple(sorted(m+n));out[z]=out.get(z,F(0))+c*d
 return {m:c for m,c in out.items() if c}
def mono(*ids):return {tuple(sorted(ids)):F(1)}
def substitution(a,mp):
 out={}
 for m,c in a.items():
  cur={():c}
  for v in m:cur=times(cur,mp.get(v,mono(v)))
  out=plus(out,cur)
 return out
def normalized(a):
 den=functools.reduce(math.lcm,(c.denominator for c in a.values()),1)
 div=functools.reduce(math.gcd,(abs(c.numerator*(den//c.denominator)) for c in a.values()),0)
 return {m:c*F(den,div) for m,c in a.items()}
def main():
 cert=read(H/'normalization-certificate.json');source=Path(cert['baselinePath'])
 assert sha(source)==cert['baselineSha256']
 assert sha(H/'candidate520-ir.json')==cert['candidateSha256']
 old=read(source);new=read(H/'candidate520-ir.json')
 assert old['fixedParameter']==new['fixedParameter']
 before={r['id']:pol(r['terms']) for r in old['residuals']}
 after={r['id']:pol(r['terms']) for r in new['residuals']}
 rn={r['name']:r['id'] for r in old['residuals']};cn={c['name']:c['id'] for c in old['coordinates']}
 maps={};removed=[];scaling={}
 for op in cert['operations']:
  pre='detector'+str(op['detector']);ids=op['ids']
  assert all(cn[pre+'.'+n]==i for n,i in ids.items())
  b=ids['B'];u=ids['U2.quadratic'];removed.append(u)
  # Old coordinates in terms of new ones. Unchanged b makes this invertible
  # on b != 0. The deleted coordinate equals b^2 on every old solution.
  for n in ['scaled_e','p','s']:maps[ids[n]]=mono(b,ids[n])
  for n in ['q','p2.quadratic','s2.quadratic','Bh.quadratic']:maps[ids[n]]=mono(b,b,ids[n])
  maps[ids['q2.quadratic']]=mono(b,b,b,b,ids['q2.quadratic'])
  maps[u]=mono(b,b)
  assert op['droppedRow']==rn[pre+'.U2.definition']
  assert set(op['updatedRows'])=={rn[pre+'.'+n] for n in ['p2.definition','s2.definition','q2.definition','firstConic','Bh.definition','secondConic']}
  for name in ['p2.definition','s2.definition','firstConic','Bh.definition']:scaling[rn[pre+'.'+name]]=mono(b,b)
  for name in ['q2.definition','secondConic']:scaling[rn[pre+'.'+name]]=mono(b,b,b,b)
  # Check concrete guard identities. If b=0, the B equation implies n=0.
  # Then w0^2=2*w1^2 implies w0=w1=0 over Q, contradicting w0*inv=1.
  w0=pol(old['values'][pre+'.W.0']['terms']);w1=pol(old['values'][pre+'.W.1']['terms'])
  inv=mono(cn[pre+'.w0Inverse']);n=mono(cn[pre+'.normOver2w0'])
  assert before[rn[pre+'.w0Inverse.definition']]==plus(mono(),times(w0,inv),-1)
  assert before[rn[pre+'.normOver2w0.definition']]==plus(plus(times(w0,w0),times(w1,w1),-2),times(w0,n),-2)
  assert substitution(before[rn[pre+'.B.definition']],{b:{}})==times(n,n)
  for suffix in ['w0Inverse.definition','normOver2w0.definition','B.definition']:
   assert before[rn[pre+'.'+suffix]]==after[rn[pre+'.'+suffix]]
  assert not (set(ids.values())-{b}) & {v for p in [w0,w1,inv,n] for m in p for v in m}
 assert sorted(removed)==sorted(cert['removedCoordinates'])
 dropped={op['droppedRow'] for op in cert['operations']}
 assert set(after)==set(before)-dropped
 for ri,p in before.items():
  transformed=substitution(p,maps)
  if ri in dropped:assert transformed=={}
  else:assert transformed==times(scaling.get(ri,mono()),after[ri]),ri
 oldcoords={c['id']:c for c in old['coordinates']};newcoords={c['id']:c for c in new['coordinates']}
 assert set(newcoords)==set(oldcoords)-set(removed)
 assert oldcoords[0]==newcoords[0]
 assert all(sum(v!=-1 for v in m)<=2 for p in after.values() for m in p)
 assert {v for p in after.values() for m in p for v in m if v!=-1}==set(newcoords)
 # Expand independently by collecting the upper triangle of each square.
 total={}
 for p in after.values():
  items=list(normalized(p).items())
  for i,(m,c) in enumerate(items):
   for j in range(i,len(items)):
    n,d=items[j];z=tuple(sorted(m+n));total[z]=total.get(z,F(0))+c*d*(1 if i==j else 2)
 total={m:c for m,c in total.items() if c}
 table=read(H/'polynomial520.json');renumber={c['sourceId']:c['id'] for c in table['coordinates']}
 assert renumber==dict(zip(sorted(newcoords),range(len(newcoords))))
 actual=pol(table['terms']);expected={tuple(-1 if v==-1 else renumber[v] for v in m):c for m,c in total.items()}
 assert actual==expected
 assert all(c.denominator==1 for c in total.values())
 assert max(sum(v!=-1 for v in m) for m in total)==4
 assert functools.reduce(math.gcd,(abs(c.numerator) for m,c in total.items() if -1 not in m),0)==1
 summary=read(H/'summary.json')
 assert summary['variables']==len(newcoords)==520
 assert summary['residuals']==len(after)==489
 assert summary['monomials']==len({tuple(v for v in m if v!=-1) for m in total})==35154
 assert summary['polynomialSha256']==sha(H/'polynomial520.json')
 # Coefficient maximum is exactly 64*S^2. Its monomial has no lower S terms.
 assert total[(-1,-1,55,55)]==64 and (55,55) not in total and (-1,55,55) not in total
 assert max(abs(c.numerator).bit_length() for m,c in total.items() if -1 not in m)<2048
 assert max(abs(c) for m,c in total.items() if m.count(-1)==1)<=768
 assert [m for m in total if m.count(-1)==2]==[(-1,-1,55,55)]
 # S=3^(2^26)>2^2048 and S>12, so all other coefficients are smaller.
 print(json.dumps({'verified':True,'baselineSha256':sha(source),'variables':len(newcoords),'witnesses':len(newcoords)-1,'residuals':len(after),'degree':4,'monomials':summary['monomials'],'content':1,'largestAbsoluteCoefficient':'64 * 3^(2^27)','rationalWitnessBijection':'retained b != 0 guards plus exact substitution identities','independentReview':'pending'},indent=2))
if __name__=='__main__':main()
