"""Factor the three normalized detector second conics, removing their s^2 coordinates."""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib,sys,copy,math,functools
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H.parent));from search import read,encode,add,mul,degree,vs
SRC=H.parents[1]/'10-combination/candidate501-ir.json'
d=json.loads(SRC.read_text());cn={c['name']:c['id'] for c in d['coordinates']};rn={r['name']:r['id'] for r in d['residuals']};rows={r['id']:read(r['terms']) for r in d['residuals']};ops=[];removed=[]
for k in range(3):
 pre=f'detector{k}';b=cn[pre+'.B'];e=cn[pre+'.normalized.scaled_e'];t=cn[pre+'.normalized.s'];t2=cn[pre+'.normalized.s2.quadratic'];q=cn[pre+'.normalized.q'];q2=cn[pre+'.normalized.q2.quadratic'];f=cn[pre+'.normalized.Bh.quadratic']
 rb,rq,rt,rc=[rn[pre+'.'+s] for s in ['Bh.definition','q2.definition','s2.definition','secondConic']]
 assert rows[rb]=={(0,(e,)):Q(17),(0,tuple(sorted((e,b)))):Q(-1),(0,(f,)):Q(-17)}
 assert rows[rt]=={(0,(t,t)):Q(1),(0,(t2,)):Q(-1)}
 assert rows[rq]=={(0,(q,q)):Q(1),(0,(q2,)):Q(-1)}
 assert rows[rc]=={(0,tuple(sorted((b,q2)))):Q(17),(0,(f,f)):Q(867),(0,tuple(sorted((f,t2)))):Q(-34),(0,(t2,t2)):Q(-1)}
 rows[rb]={(0,(e,)):Q(17),(0,tuple(sorted((e,b)))):Q(-1),(0,tuple(sorted((t,f)))):Q(-17)}
 rows[rc]={(0,tuple(sorted((b,q2)))):Q(17),(0,(f,f)):Q(867),(0,tuple(sorted((t,f)))):Q(-34),(0,(t,t)):Q(-1)}
 del rows[rt];removed.append(t2)
 ops.append({'detector':k,'b':b,'e':e,'t':t,'t2':t2,'q':q,'q2':q2,'f':f,'rows':{'Bh':rb,'q2':rq,'s2':rt,'secondConic':rc}})
coords=[]
for c in d['coordinates']:
 if c['id'] in removed:continue
 c=copy.deepcopy(c)
 for op in ops:
  if c['id']==op['f']:c['name']=f'detector{op["detector"]}.factored.v'
  if c['id']==op['q']:c['name']=f'detector{op["detector"]}.factored.q'
  if c['id']==op['q2']:c['name']=f'detector{op["detector"]}.factored.q2'
 coords.append(c)
out={'format':'factored-pole-quadratic-residual-system-v1','fixedParameter':d['fixedParameter'],'coordinates':coords,'residuals':[dict(r,terms=encode(rows[r['id']])) for r in d['residuals'] if r['id'] in rows], 'status':'Candidate pending independent review; exact soundness map, positive-pole completeness map.'}
(H/'candidate498-ir.json').write_text(json.dumps(out,indent=2)+'\n')
total={}
for p in rows.values():
 den=functools.reduce(math.lcm,(c.denominator for c in p.values()),1);div=functools.reduce(math.gcd,(abs(c.numerator*(den//c.denominator)) for c in p.values()),0)
 p={m:c*Q(den,div) for m,c in p.items()};total=add(total,mul(p,p))
assert {x for p in rows.values() for x in vs(p)}=={c['id'] for c in coords}
poly={'fixedParameter':out['fixedParameter'],'terms':encode(total)}
(H/'polynomial498.json').write_text(json.dumps(poly,indent=2)+'\n')
cert={'source':str(SRC),'sourceSha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256((H/'candidate498-ir.json').read_bytes()).hexdigest(),'polynomialSha256':hashlib.sha256((H/'polynomial498.json').read_bytes()).hexdigest(),'operations':ops,'removedCoordinates':removed,'soundnessMap':'old_f=t*v, old_q=t*q, old_q2=t^2*q2, old_t2=t^2','completenessMap':'For b>0: if t!=0 divide f and q by t, q2 by t^2; if t=0 then f=q=q2=0 and choose v=q=q2=0.'}
(H/'certificate498.json').write_text(json.dumps(cert,indent=2)+'\n')
summary={'variables':len(coords),'witnesses':len(coords)-1,'residuals':len(rows),'degree':degree(total),'monomials':len({m for s,m in total}),'content':functools.reduce(math.gcd,(abs(c.numerator) for (s,m),c in total.items() if s==0),0),'fixedParameter':out['fixedParameter'],'largestCoefficient':'16*C^2','status':'pending independent review'}
(H/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
