# A 498-variable candidate by factoring the detector second conics

This packet removes three more coordinates from the pinned 501-variable source. Its status is **pending independent review**. No shared manuscript or previous report has been edited.

| Quantity | Source | Candidate |
| --- | ---: | ---: |
| Total variables, including the input | 501 | 498 |
| Existential witnesses | 500 | 497 |
| Quadratic residuals | 470 | 467 |
| Degree | 4 | 4 |
| Nonzero monomials | See source certificate | 24,712 |
| Content | 1 | 1 |

The fixed integer remains `C=3^(2^25)`. The exact largest coefficient magnitude remains `16*C^2 = 16*3^(2^26)`. No large integer was expanded.

## Source binding

The source is `10-combination/candidate501-ir.json`, SHA-256

```
6a31040f85e30cc6f9d076bf6c92218be110e0829e93333d7e99f93a6b2f0d9a
```

The new residual system is `candidate498-ir.json`, SHA-256

```
0b72432400cb01cb1531a26ca370ee5988bd8b8d9537aaa8640a3e98f4cfabba
```

The full quartic table is `polynomial498.json`, SHA-256

```
59ad8e3bdcd761590dc2eeecc772344f4ebade5001482364e27e04e4744ea927
```

`certificate498.json` records the exact coordinate and row IDs for every replacement. The construction preserves the input coordinate and every equation outside the three private detector pole blocks.

## One detector block

Write `b` for the source coordinate named `detector{k}.B`. It is the pole input; the traditional conic parameter is `17b`. The source already uses the earlier pole normalization. Write its normalized witnesses as `E,p,t,q`, its square coordinates as `p2,t2,q2`, and its normalized `Bh.quadratic` coordinate as `F`. The relevant equations are

```
17E - Eb - 17F = 0,
t^2 - t2 = 0,
q^2 - q2 = 0,
17b q2 + 867F^2 - 34F t2 - t2^2 = 0.
```

The first conic and the p-square definition stay unchanged. The factor 17 in the F definition is intentional: the original compiler stores the traditional Bh divided by 17.

Introduce new witnesses `v,Q,Q2`, reusing the old coordinate positions of `F,q,q2`. Remove the coordinate t2 and its defining residual. Replace the displayed four equations by

```
17E - Eb - 17tv = 0,
Q^2 - Q2 = 0,
17b Q2 + 867v^2 - 34tv - t^2 = 0.
```

Every equation remains quadratic. There are three copies, one for each detector, so this removes three coordinates and three residuals.

## Soundness map for every rational new solution

Reconstruct the old coordinates by the polynomial formulas

```
F = tv,
q = tQ,
q2 = t^2 Q2,
t2 = t^2.
```

Leave every other coordinate unchanged. The old Bh residual becomes exactly the new Bh residual. The old t-square residual becomes identically zero. The old q-square residual and old second-conic residual become t^2 times their new counterparts. Therefore every rational solution of the new system gives a rational solution of the entire old system with the same input.

This direction uses neither t nonzero nor b positive. In particular, dividing a residual by t^2 has not introduced spurious input values: the displayed polynomial reconstruction works at t=0 as well.

## Completeness map, including t=0

The required source property is that every integer input has a source solution in which all three detector inputs b are positive. This is already supplied by the inherited completeness construction, as detailed below. We do not impose b positive on arbitrary rational solutions of the new system.

Take such a source solution. If t is nonzero, set

```
v = F/t,
Q = q/t,
Q2 = q2/t^2,
```

and discard t2. The source equation t2=t^2 and the preceding polynomial identities show that the new equations hold.

If t=0, then t2=0 and q2=q^2. The old second conic becomes

```
17b q^2 + 867F^2 = 0.
```

Because b>0 and the coordinates are rational, both summands are nonnegative, and their sum can vanish only when q=F=0. Also q2=0. Choose v=Q=Q2=0. The new second conic and q-square equation vanish. The new Bh equation equals the old Bh equation with F=0, so it vanishes too. No division by zero occurs.

Apply this independently to the three detectors. All replacement coordinates are private to these blocks, so the three maps do not interfere.

This is an exact soundness map on the full rational zero set and an exact completeness map on the source's positive-pole witnesses. It is not claimed to be a bijection on every old fixed-b fiber when b is negative. That stronger claim is unnecessary and has not been used.

## Where positive pole inputs come from

The pinned manuscript is `manuscripts/quartic_v11.tex`, SHA-256

```
1210d2e6f409e502fc9c95afc248fac16a9df48c760a396143780c20ec80b662
```

In its completeness proof around lines 11215-11336, the source first fixes the roots, scales, continuity neighborhoods and real bounds, then chooses the contact primes and a sufficiently large real parameter lambda. Around lines 11317-11327 it explicitly obtains

```
R_r ~ A_r^(-6) lambda^(-1),
T_r = 2 + O(lambda^(-3)),
B_r ~ (4 A_r^6 lambda)^(-1),
0 < B_r < 17.
```

This B_r is the pole input called b above. The preparation-zero pole witnesses are supplied after this positivity conclusion. Section `subsec:v9-completeness` and `subsec:v9-deep-completeness`, around lines 19641-19739, retain the same real bounds and pole construction for the three positive product-height scales and asymmetric formal depth.

The changes already composed into source501 preserve this property. The mixed-order proposal uses a new continuity modulus for the changed rational functions but the same large-real pole estimate. The earlier pole normalization leaves the input b unchanged. The trace guards alter which comparison witnesses are selected but retain the real-progression construction. The anchor and scalar norm changes occur before the roots, scales and real bounds are fixed. The new Laurent circuit is an exact replacement of weight coordinates, leaving the weights and hence b unchanged. None of those steps requires taking negative detector inputs.

This is a traced completeness property of the same construction, not an added number-theoretic hypothesis. Independent review should still confirm it against the accepted source501 composition. This packet does not independently re-approve my earlier pole normalization or the other source501 proposals.

## Verification

Run, with Python 3.10 or newer,

```
python -B build.py
python -B verify.py
```

The producer imports sparse polynomial helpers from the earlier local search module. The verifier imports neither the producer nor those helpers. It implements sparse arithmetic and upper-triangular sum-of-squares expansion separately.

The verifier checks:

- source, candidate and polynomial hashes;
- every old residual after simultaneous polynomial reconstruction;
- the exact residual at the t=0 exceptional branch and the proposed zero lift;
- the removed coordinate/row sets, input preservation and full coordinate coverage;
- residual degree at most two;
- the complete primitive-integer sum of squares against every coefficient in `polynomial498.json`;
- degree four, 24,712 monomials, content one, and the exact coefficient maximum.

Its positivity step is the elementary implication `b>0 and 17b q^2+867F^2=0` implies `q=F=0`. The machine checks the exact polynomial to which that implication is applied; the completeness source supplies the strict inequality.

`verify.py` passed. Its output is recorded in `verification.json`. These finite checks certify the transformation and table; they do not independently prove the inherited arithmetic theorem or establish acceptance of the 498-variable candidate.
