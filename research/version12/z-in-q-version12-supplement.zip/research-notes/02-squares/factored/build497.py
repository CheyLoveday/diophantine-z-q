"""Apply the same exact factorization to the prepared scalar pole."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,hashlib,copy,math,functools
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H.parent));from search import read,encode,add,mul,degree,vs,subst
SRC=H/'candidate498-ir.json';d=json.loads(SRC.read_text());cn={c['name']:c['id'] for c in d['coordinates']};rn={r['name']:r['id'] for r in d['residuals']};rows={r['id']:read(r['terms']) for r in d['residuals']}
b,t,t2,q,q2,f=[cn[n] for n in ['scalar.b.quadratic','scalar.s','scalar.s2.quadratic','scalar.q','scalar.q2.quadratic','scalar.Bh.quadratic']]
rb,rq,rt,rc=[rn[n] for n in ['scalar.Bh.definition','scalar.q2.definition','scalar.s2.definition','scalar.secondConic']]
rows[rb]=subst(rows[rb],f,{(0,tuple(sorted((t,f)))):Q(1)})
# Simultaneous monomial scaling only uses t, which is never itself replaced.
p=rows[rc]
for v,newp in [(f,{(0,tuple(sorted((t,f)))):Q(1)}),(q2,{(0,tuple(sorted((t,t,q2)))):Q(1)}),(t2,{(0,(t,t)):Q(1)})]:p=subst(p,v,newp)
assert all(m.count(t)>=2 for s,m in p)
def remove_two(m):
 m=list(m);m.remove(t);m.remove(t);return tuple(m)
rows[rc]={(s,remove_two(m)):a for (s,m),a in p.items()};del rows[rt]
coords=[]
for c in d['coordinates']:
 if c['id']==t2:continue
 c=copy.deepcopy(c)
 if c['id']==f:c['name']='scalar.factored.v'
 if c['id']==q:c['name']='scalar.factored.q'
 if c['id']==q2:c['name']='scalar.factored.q2'
 coords.append(c)
out=dict(d,coordinates=coords,residuals=[dict(r,terms=encode(rows[r['id']])) for r in d['residuals'] if r['id'] in rows],status='Candidate pending independent review; all four pole second conics factored.')
(H/'candidate497-ir.json').write_text(json.dumps(out,indent=2)+'\n');total={}
for p in rows.values():
 den=functools.reduce(math.lcm,(v.denominator for v in p.values()),1);g=functools.reduce(math.gcd,(abs(v.numerator*(den//v.denominator)) for v in p.values()),0)
 p={m:v*Q(den,g) for m,v in p.items()};total=add(total,mul(p,p))
(H/'polynomial497.json').write_text(json.dumps({'fixedParameter':out['fixedParameter'],'terms':encode(total)},indent=2)+'\n')
cert={'source':str(SRC),'sourceSha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'candidateSha256':hashlib.sha256((H/'candidate497-ir.json').read_bytes()).hexdigest(),'polynomialSha256':hashlib.sha256((H/'polynomial497.json').read_bytes()).hexdigest(),'ids':{'b':b,'t':t,'t2':t2,'q':q,'q2':q2,'f':f},'rows':{'Bh':rb,'q2':rq,'s2':rt,'secondConic':rc},'counts':{'variables':len(coords),'witnesses':len(coords)-1,'residuals':len(rows),'degree':degree(total),'monomials':len({m for s,m in total})}}
semantic_source=H.parents[1]/'03-depth/beta12/final/candidate-ir.json'
cert['semanticSource']=str(semantic_source)
cert['semanticSourceSha256']=hashlib.sha256(semantic_source.read_bytes()).hexdigest()
(H/'certificate497.json').write_text(json.dumps(cert,indent=2)+'\n');print(json.dumps(cert['counts'],indent=2))
