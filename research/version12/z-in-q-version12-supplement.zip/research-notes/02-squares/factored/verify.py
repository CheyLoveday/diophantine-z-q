"""Read-only exact verification of the second-conic factorization.
Independent of build.py and its polynomial implementation.
Completeness uses the separately documented positive-b witnesses.
"""
import json,hashlib,math,functools
from fractions import Fraction as F
from pathlib import Path
H=Path(__file__).resolve().parent

def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def poly(ts):
 out={}
 for t in ts:
  m=tuple([-1]*t.get('sPower',0)+t['monomial']);assert m==tuple(sorted(m))
  out[m]=out.get(m,F(0))+F(t['coefficient'])
 return {m:c for m,c in out.items() if c}
def add(a,b,k=F(1)):
 r=a.copy()
 for m,c in b.items():r[m]=r.get(m,F(0))+k*c
 return {m:c for m,c in r.items() if c}
def mul(a,b):
 r={}
 for m,c in a.items():
  for n,d in b.items():
   k=tuple(sorted(m+n));r[k]=r.get(k,F(0))+c*d
 return {m:c for m,c in r.items() if c}
def mon(*vs):return {tuple(sorted(vs)):F(1)}
def sub(a,mp):
 r={}
 for m,c in a.items():
  q={():c}
  for v in m:q=mul(q,mp.get(v,mon(v)))
  r=add(r,q)
 return r
def norm(a):
 d=functools.reduce(math.lcm,(c.denominator for c in a.values()),1)
 g=functools.reduce(math.gcd,(abs(c.numerator*(d//c.denominator)) for c in a.values()),0)
 return {m:c*F(d,g) for m,c in a.items()}
def main():
 cert=read(H/'certificate498.json');source=Path(cert['source']);assert sha(source)==cert['sourceSha256']
 assert sha(H/'candidate498-ir.json')==cert['candidateSha256'];assert sha(H/'polynomial498.json')==cert['polynomialSha256']
 old=read(source);new=read(H/'candidate498-ir.json')
 before={r['id']:poly(r['terms']) for r in old['residuals']};after={r['id']:poly(r['terms']) for r in new['residuals']}
 names={c['name']:c['id'] for c in old['coordinates']};rn={r['name']:r['id'] for r in old['residuals']}
 maps={};multipliers={};deleted=set()
 for op in cert['operations']:
  k=op['detector'];pre=f'detector{k}';b,e,t,t2,q,q2,f=[op[x] for x in ['b','e','t','t2','q','q2','f']]
  assert [b,e,t,t2,q,q2,f]==[names[pre+'.B']]+[names[pre+'.normalized.'+n] for n in ['scaled_e','s','s2.quadratic','q','q2.quadratic','Bh.quadratic']]
  rb,rq,rt,rc=[op['rows'][x] for x in ['Bh','q2','s2','secondConic']]
  assert [rb,rq,rt,rc]==[rn[pre+'.'+n] for n in ['Bh.definition','q2.definition','s2.definition','secondConic']]
  maps[f]=mon(t,f);maps[q]=mon(t,q);maps[q2]=mon(t,t,q2);maps[t2]=mon(t,t)
  multipliers[rq]=mon(t,t);multipliers[rc]=mon(t,t);deleted.add(rt)
  # Check the complete exceptional branch. Setting t=0 forces t2=0;
  # q2=q^2 and the old second conic becomes 17*b*q^2+867*f^2.
  assert before[rt]==add(mon(t,t),mon(t2),-1)
  assert before[rq]==add(mon(q,q),mon(q2),-1)
  branch=sub(before[rc],{t:{},t2:{},q2:mon(q,q)})
  assert branch==add({tuple(sorted((b,q,q))):F(17)},mon(f,f),867)
  # For b>0 this is zero only if q=f=0. Then the proposed zero lift
  # has every replaced residual except Bh identically zero. Bh is
  # exactly the old Bh equation with f=0, which holds by assumption.
  lift={t:{},q:{},q2:{},f:{}}
  assert sub(after[rq],lift)=={} and sub(after[rc],lift)=={}
  assert sub(after[rb],lift)==sub(before[rb],{f:{}})
 assert set(after)==set(before)-deleted
 for r,p in before.items():
  got=sub(p,maps)
  assert got==({} if r in deleted else mul(multipliers.get(r,mon()),after[r])),r
 oldids={c['id'] for c in old['coordinates']};newids={c['id'] for c in new['coordinates']}
 assert oldids-newids=={op['t2'] for op in cert['operations']}==set(cert['removedCoordinates'])
 assert newids<=oldids and len(newids)==498
 assert old['fixedParameter']==new['fixedParameter']=={'name':'C','value':'3^(2^25)','coordinate':False}
 assert old['coordinates'][0]==new['coordinates'][0]
 assert {v for p in after.values() for m in p for v in m if v!=-1}==newids
 assert all(sum(v!=-1 for v in m)<=2 for p in after.values() for m in p)
 total={}
 for p in after.values():
  terms=list(norm(p).items())
  for i,(m,c) in enumerate(terms):
   for j in range(i,len(terms)):
    n,d=terms[j];z=tuple(sorted(m+n));total[z]=total.get(z,F(0))+c*d*(1 if i==j else 2)
 total={m:c for m,c in total.items() if c}
 assert total==poly(read(H/'polynomial498.json')['terms'])
 assert all(c.denominator==1 for c in total.values())
 assert max(sum(v!=-1 for v in m) for m in total)==4
 assert functools.reduce(math.gcd,(abs(c.numerator) for m,c in total.items() if -1 not in m),0)==1
 c2={m:c for m,c in total.items() if m.count(-1)==2}
 assert c2=={(-1,-1,57,57):F(16)} and (57,57) not in total and (-1,57,57) not in total
 assert max(abs(c) for m,c in total.items() if m.count(-1)==1)<=48
 assert max(abs(c.numerator).bit_length() for m,c in total.items() if -1 not in m)<2048
 # C>2^2048 and C>48 prove the exact coefficient maximum 16*C^2.
 stats={'verified':True,'variables':len(newids),'witnesses':len(newids)-1,'residuals':len(after),'degree':4,'monomials':len({tuple(v for v in m if v!=-1) for m in total}),'content':1,'largestCoefficient':'16 * 3^(2^26)','sourceSha256':sha(source),'candidateSha256':sha(H/'candidate498-ir.json'),'polynomialSha256':sha(H/'polynomial498.json'),'soundness':'exact polynomial reconstruction for every rational new solution','completeness':'explicit inverse for nonzero t and checked zero branch, using inherited positive-b completeness witnesses','independentReview':'pending'}
 assert stats['monomials']==24712 and stats['residuals']==467
 print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
