import json
from pathlib import Path
h=Path(__file__).resolve().parent;p=h.parents[1]/'10-combination/candidate501-ir.json'
d=json.loads(p.read_text());cs={c['id']:c for c in d['coordinates']}
for r in d['residuals']:
 if r['name'].startswith('detector0.') and any(t in r['name'] for t in ['.Bh.','.s2.','.q2.','Conic']):
  print(r);print([cs[v]['name'] for v in sorted({v for t in r['terms'] for v in t['monomial']})])
