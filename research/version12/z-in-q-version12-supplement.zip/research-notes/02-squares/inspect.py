import json, collections
p='work/quartic-version6-release/repository/quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json'
d=json.load(open(p)); rows=d['residuals']; cs={c['id']:c for c in d['coordinates']}
occ=collections.defaultdict(list)
for r in rows:
 for v in {v for t in r['terms'] for v in t['monomial']}:occ[v].append(r)
for v,c in cs.items():
 if len(occ[v])<=3:
  print(v,c['name'],len(occ[v]),'; '.join(str(r['id'])+':'+r['name'] for r in occ[v]))
print('BLOCKS',collections.Counter(c['block'] for c in cs.values()))
