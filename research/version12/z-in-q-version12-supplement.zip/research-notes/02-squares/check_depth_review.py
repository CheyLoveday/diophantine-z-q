from pathlib import Path
import json,hashlib,subprocess,shutil
H=Path(__file__).resolve().parent
W=H.parent
R=W.parent/'quartic-version6-release/repository'
D=W/'03-depth'
source=R/'quartics/quartic-523-540/source-reproduction/builders/odd-product-asymmetric-source.cjs'
old=source.read_text();new=(D/'beta12/build_source.cjs').read_text()
replacements=[("value:'3^(2^27)'","value:'3^(2^26)'"),
("LV=PV.map((p,i)=>log('logV'+i,p,40))","LV=PV.map((p,i)=>log('logV'+i,p,i===1?12:40))"),
("tests.push({value:fsub(L[i],LP[i]),order:40})","tests.push({value:fsub(L[i],LP[i]),order:i===1?12:40})"),
("tests.push({value:fsub(L[1],[beta,zero]),order:40}","tests.push({value:fsub(L[1],[beta,zero]),order:12}"),
('for(let m of [1,40])coeffs[m]','for(let m of [1,12,40])coeffs[m]'),
("const n=co.length-1,split=n===9?5:n===7?4:null;","const n=co.length-1,split=n===9?5:n===5?3:n===2?1:null;\n if(n===2){const q2=rsq(name+'.power2',q); return saveF(name,[0,1].map(j=>assign(name+'.sum.'+j,add(co[0][j],mul(co[1][j],q),mul(co[2][j],q2)))));}"),
("let w=fmul('detector'+r+'.W',evalSym('detector'+r+'.E1',coeffs[1],q1),evalSym('detector'+r+'.E40',coeffs[40],q40));","let w=fmul('detector'+r+'.W',fmul('detector'+r+'.Wfirst',evalSym('detector'+r+'.E1',coeffs[1],q1),evalSym('detector'+r+'.E12',coeffs[12],q12)),evalSym('detector'+r+'.E40',coeffs[40],q40));")]
for a,b in replacements:
 assert old.count(a)==1,(a,old.count(a));old=old.replace(a,b)
assert old==new
scratch=H/'review-depth-replay';(scratch/'sources').mkdir(parents=True,exist_ok=True)
(scratch/'build_source.cjs').write_text(new)
shutil.copyfile(D/'beta12/sources/diophantine_optimization_20261106_v3.tex',scratch/'sources/diophantine_optimization_20261106_v3.tex')
with (scratch/'builder.log').open('w') as f:subprocess.run(['node',str(scratch/'build_source.cjs')],stdout=f,check=True)
for name in ['raw-ir.json','raw-translated-ir.json','census.json']:
 assert json.loads((scratch/name).read_text())==json.loads((D/'beta12'/name).read_text()),name
# Use the contributor's driver with output destinations changed to this review folder.
# Its certificate engines are the already published standalone verifiers.
driver=(D/'verify.py').read_text()
driver=driver.replace("ROOT=Path(__file__).resolve().parent", "ROOT=Path("+repr(str(D))+")")
driver=driver.replace("str(d/'independent-check.json')", "str(Path("+repr(str(H/'review-depth-checker.json'))+"))")
driver=driver.replace("(d/'checker.log').open('w')", "Path("+repr(str(H/'review-depth-checker.log'))+").open('w')")
driver=driver.replace("read(d/'independent-check.json')", "read(Path("+repr(str(H/'review-depth-checker.json'))+"))")
driver=driver.replace("(f/'VERIFICATION.json').write_text", "Path("+repr(str(H/'review-depth-verification.json'))+").write_text")
(H/'review-depth-driver.py').write_text(driver)
subprocess.run([__import__('sys').executable,'-B',str(H/'review-depth-driver.py')],check=True)
# Independently check the exact mixed-depth rows survive into candidate505.
# Other transformations, especially this reviewer's own pole patch, are excluded.
d=json.loads((D/'beta12/final/candidate-ir.json').read_text())
c=json.loads((W/'10-combination/candidate505-ir.json').read_text())
cr={r['name']:r for r in c['residuals']};checked=[]
for r in d['residuals']:
 if r['block'] in ['parameters_and_logarithms','direct_tests_and_shared_symmetric_coefficients'] or (r['name'].startswith('detector') and any(t in r['name'] for t in ['.E1.','.E12.','.E40.','.Wfirst.','.W.','.q12.','.q40.'])):
  assert r['name'] in cr and r['terms']==cr[r['name']]['terms'],r['name'];checked.append(r['name'])
paths=[R/'manuscripts/quartic_v11.tex',R/'docs/quartic-523-540/addition.tex',source,D/'REPORT.md',D/'experiment.py',D/'beta12/build_source.cjs',D/'beta12/raw-translated-ir.json',D/'beta12/compiled/compiled-ir.json',D/'beta12/final/candidate-ir.json',D/'beta12/final/modulo-certificate.json',D/'beta12/final/polynomial/polynomial.json',W/'10-combination/candidate505-ir.json',W/'10-combination/certificate505.json',W/'10-combination/REPORT.md']
out={'sourceEditsExactlyMatched':True,'freshRawReplayMatched':True,'unchangedDepthRowsIn505':len(checked),'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
(H/'review-depth-sources.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='hashes'},indent=2))
