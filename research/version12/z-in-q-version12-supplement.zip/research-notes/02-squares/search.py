import json
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as Q
BASE=Path(__file__).resolve().parent
SRC=BASE.parents[1]/'quartic-version6-release/repository/quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json'
def read(ts):return {(t.get('sPower',0),tuple(t['monomial'])):Q(t['coefficient']) for t in ts}
def add(a,b,c=Q(1)):
 a=a.copy()
 for m,v in b.items():
  a[m]=a.get(m,0)+c*v
  if not a[m]:del a[m]
 return a
def mulmono(a,m,c=Q(1)):return {(s+m[0],tuple(sorted(t+m[1]))):v*c for (s,t),v in a.items()}
def mul(a,b):
 r={}
 for m,c in b.items():r=add(r,mulmono(a,m,c))
 return r
def subst(a,x,q):
 r={}
 for (s,m),c in a.items():
  p={(s,tuple(v for v in m if v!=x)):c}
  for i in range(m.count(x)):p=mul(p,q)
  r=add(r,p)
 return r
def degree(a):return max((len(m) for s,m in a),default=0)
def vs(a):return {x for s,m in a for x in m}
def encode(a):return [{'sPower':s,'monomial':list(m),'coefficient':str(c)} for (s,m),c in sorted(a.items())]
def divides(m,n):
 if m[0]>n[0]:return None
 t=list(n[1])
 for x in m[1]:
  if x not in t:return None
  t.remove(x)
 return (n[0]-m[0],tuple(t))
if __name__=='__main__':
 d=json.loads(SRC.read_text());rows={r['id']:read(r['terms']) for r in d['residuals']};cs={c['id']:c for c in d['coordinates']}
 index=defaultdict(list)
 for ri,p in rows.items():
  for m in p:
   if len(m[1])==2:index[m].append(ri)
 # Exact, bounded high-degree closure. Only multiply original unaffected equations.
 results=[];stats=defaultdict(int)
 for x,c in cs.items():
  if c.get('protected'):continue
  affected={ri for ri,p in rows.items() if x in vs(p)}
  pivots=[ri for ri in affected if rows[ri].get((0,(x,))) and all(x not in m or (s,m)==(0,(x,)) for s,m in rows[ri])]
  for pivot in pivots:
   q=add({},rows[pivot],-1/rows[pivot][(0,(x,))]);del q[(0,(x,))]
   outputs={ri:subst(rows[ri],x,q) for ri in affected-{pivot}}
   basis={};pairs=set();overflow=False
   # Include union target high monomials, close under their matching row products.
   pending={m for p in outputs.values() for m in p if len(m[1])>2};seen=set()
   while pending:
    m=pending.pop()
    if m in seen:continue
    seen.add(m)
    if len(seen)>1500:overflow=True;break
    from itertools import combinations
    for tt in set(combinations(m[1],2)):
     # S-free source leading quadratic terms suffice here.
     sm=(0,tt)
     quot=divides(sm,m)
     for ri in index.get(sm,[]):
      if ri in affected or (ri,quot) in pairs:continue
      pairs.add((ri,quot));pol=mulmono(rows[ri],quot);vec={k:v for k,v in pol.items() if len(k[1])>2}
      pending.update(vec.keys()-seen)
      cert={(ri,quot):Q(1)}
      while vec:
       lead=max(vec)
       if lead not in basis:
        a=vec[lead];basis[lead]=({k:v/a for k,v in vec.items()},{k:v/a for k,v in cert.items()});break
       bv,bc=basis[lead];a=vec[lead];vec=add(vec,bv,-a);cert=add(cert,bc,-a)
   if overflow:stats['overflow']+=1;continue
   changes=[];good=True
   for ri,p in outputs.items():
    vec={k:v for k,v in p.items() if len(k[1])>2};cert={}
    while vec:
     lead=max(vec)
     if lead not in basis:good=False;break
     bv,bc=basis[lead];a=vec[lead];vec=add(vec,bv,-a);cert=add(cert,bc,-a)
    if not good:break
    out=p
    for (rr,m),a in cert.items():out=add(out,mulmono(rows[rr],m,a))
    assert degree(out)<=2
    changes.append({'row':ri,'result':encode(out),'multiples':[{'row':rr,'factor':encode({m:a})} for (rr,m),a in cert.items()]})
   if good:
    result={'coordinate':x,'name':c['name'],'pivot':pivot,'replacement':encode(q),'changes':changes}
    results.append(result);print('SUCCESS',x,c['name'],pivot,flush=True)
   else:stats['failed']+=1
  if x%25==0:print('progress',x,dict(stats),flush=True)
 (BASE/'search-results.json').write_text(json.dumps({'results':results,'stats':stats},indent=2))
 print('done',len(results),dict(stats))
