"""Re-run existing independent verifiers; redirect all reports into this review.

This runner does not claim to be an independently authored polynomial checker.
It runs the already separate verifiers, preserving their input paths and forbidding
their report writes to alter the reviewed packets.
"""
from pathlib import Path
import contextlib
import runpy
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "10-combination"
OUT = HERE / "replay"
OUT.mkdir(exist_ok=True)
original_write = Path.write_text
written = []

def redirected_write(path, text, *args, **kwargs):
    path = Path(path)
    target = OUT / (current + "-" + path.name)
    written.append((str(path), str(target)))
    return original_write(target, text, *args, **kwargs)

Path.write_text = redirected_write
sys.path.insert(0, str(SOURCE))
for current, args in [
    ("verify", ["--product"]),
    ("verify504", []),
    ("verify501", []),
    ("verify499", []),
    ("verify498", []),
]:
    script = SOURCE / (current + ".py")
    sys.argv = [str(script), *args]
    with (OUT / (current + ".log")).open("w", encoding="utf-8") as log:
        with contextlib.redirect_stdout(log):
            runpy.run_path(str(script), run_name="__main__")
    print(current, "PASS")
Path.write_text = original_write
original_write(OUT / "redirected-writes.txt", "\n".join(a + " -> " + b for a,b in written) + "\n")
